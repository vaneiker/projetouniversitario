﻿using Agent.Integration.Service.Entity.Entities;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Core.Objects;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agent.Integration.Service.Data.Repositories
{
    public class DocumentRepository : BaseRepository
    {

        public DocumentRepository(DbContext dbcontext) : base(dbcontext) { }

        public RepositoryResult SetDocument(Document parameter)
        {
            var result = new RepositoryResult();


            var realDocumentId = new ObjectParameter("Document_id", parameter.DocumentId);
                       
            var temp = _dbContext.SP_SET_DOCUMENT(parameter.DocTypeId,
                                                  parameter.DocCategoryId,
                                                  realDocumentId,
                                                  parameter.DocumentBinary,
                                                  parameter.DocumentName,
                                                  parameter.FileCreationDate,
                                                  parameter.FileExpireDate,
                                                  parameter.userId);

            result = temp.Select(x => new RepositoryResult
            {
                Action = x.Action,
                DocTypeId = x.Doc_Type_Id,
                DocCategoryId = x.Doc_Category_Id,
                DocumentId = x.Document_Id
            }).FirstOrDefault();

            return
                result;
        }

        public RepositoryResult SetExportedFile(Document.ExportedFiles parameter)
        {
            var result = new RepositoryResult();
            var temp = _dbContext.SET_EXPORTED_FILES(parameter.ExportedFilesId,
                                                     parameter.AgentId,
                                                     parameter.DocTypeId,
                                                     parameter.DocCategoryId,
                                                     parameter.DocumentId,
                                                     parameter.DocumentName,
                                                     parameter.ExportedDate,
                                                     parameter.UserId);

            result = temp.Select(x => new RepositoryResult
            {
                Action = x.Action,
                ExportedFilesId = x.Exported_Files_Id,
                AgentId = x.Agent_Id,
                DocTypeId = x.Doc_Type_Id,
                DocCategoryId = x.Doc_Category_Id,
                DocumentId = x.Document_Id,
                DocumentName = x.DocumentName,
                ExportedDate = x.Exported_Date,
                CreateDate = x.Create_Date,
                ModiDate = x.Modi_Date,
                CreateUsrId = x.Create_UsrId,
                ModiUsrId = x.Modi_UsrId,
                Hostname = x.Hostname
            }).FirstOrDefault();

            return
                result;
        }

        public List<RepositoryResult> GetDocumentForAgents()
        {
            var result = new List<RepositoryResult>();
            var temp = _dbContext.SP_GET_DOCUMENT_CATEGORY_BY_PARENT(224);/*ATLAgentDocumentType*/

            result = temp.Select(x => new RepositoryResult
            {
                DocTypeId = x.Doc_Type_Id,
                DocCategoryId = x.Doc_Category_Id,
                DocCategoryDesc = x.Doc_Category_Desc
            }).ToList();

            return
                result;
        }

    }
}
