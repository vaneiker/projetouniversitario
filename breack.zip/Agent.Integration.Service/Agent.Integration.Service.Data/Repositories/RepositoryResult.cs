﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agent.Integration.Service.Data.Repositories
{
    public class RepositoryResult
    {
        public string Action { get; set; }
        public int? CorpId { get; set; }
        public int? AgentId { get; set; }
        public int? RegionId { get; set; }
        public int? CountryId { get; set; }
        public int? DomesticRegId { get; set; }
        public int? StateProvId { get; set; }
        public int? CityId { get; set; }
        public int? OfficeId { get; set; }
        public string Office_Desc { get; set; }
        public bool AgentAssingedStatus { get; set; }
        public int? AgentTypeId { get; set; }
        public int? DirectoryId { get; set; }
        public int? DirDetailId { get; set; }
        public int? CommTypeId { get; set; }
        public int? DirectoryTypeId { get; set; }
        public int SeqNo { get; set; }
        public int? BlTypeID { get; set; }
        public int? BlId { get; set; }
        public int? ProductId { get; set; }
        public int? ChainId { get; set; }
        public string BussinessLineName { get; set; }
        public int? ChainDetId { get; set; }
        public int? DistributionId { get; set; }
        public int? DocTypeId { get; set; }
        public int? DocCategoryId { get; set; }
        public string DocCategoryDesc { get; set; }
        public int? DocumentId { get; set; }
        public string DocumentName { get; set; }
        public DateTime? ExportedDate { get; set; }
        public DateTime? CreateDate { get; set; }
        public DateTime? ModiDate { get; set; }
        public int? CreateUsrId { get; set; }
        public int? ModiUsrId { get; set; }
        public string Hostname { get; set; }
        public int? ExportedFilesId { get; set; }
        public int ChainLevelId { get; set; }
        public string ChainlevelDesc { get; set; }

        public int ProvinceId { get; set; }
        public string ProvinceDesc { get; set; }
        public int MunicipeId { get; set; }
        public string MunicipeDesc { get; set; }
        public int CitySysflexId { get; set; }
        public string CitySysflexDesc { get; set; }

        public string AgentCode { get; set; }
        public string FirstName { get; set; }
        public string FirstLastname { get; set; }
        public string NameId { get; set; }
        public string SourceId { get; set; }

        public DateTime DateOut { get; set; }
        public DateTime DateIn { get; set; }
        public string Note { get; set; }
        public string User { get; set; }
        public int? NewSupervisAgentId { get; set; }
        public int? NewSupervisAgentCode { get; set; }
        public string AgentIds { get; set; }
        public string AgentCodes { get; set; }
        public int ModiUser { get; set; }
        public int? UserID { get; set; }
        public string Email { get; set; }
        public string UserLogin { get; set; }

    }
}
