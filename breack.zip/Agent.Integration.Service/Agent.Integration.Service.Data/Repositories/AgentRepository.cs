﻿using Agent.Integration.Service.Entity.Entities;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Core.Objects;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Agent.Integration.Service.Data.EF_MODEL_SECURITY;

namespace Agent.Integration.Service.Data.Repositories
{
    public class AgentRepository : BaseRepository
    {
        public AgentRepository(DbContext dbContext) : base(dbContext) { }

        public RepositoryResult SetAgent(AgentIntegration.Agent parameter)
        {
            var result = new RepositoryResult();
            var temp = _dbContext.SP_SET_EN_AGENT(parameter.AgentId,
                                                  parameter.IdentityTypeId,
                                                  parameter.IdentificationNumber,
                                                  parameter.AgentCode,
                                                  parameter.NameId,
                                                  parameter.FirstName,
                                                  parameter.MiddleName,
                                                  parameter.FirstLastName,
                                                  parameter.SecondLastname,
                                                  parameter.NickName,
                                                  parameter.DateOfBirth,
                                                  parameter.PaymentTypeId,
                                                  parameter.ABANumber,
                                                  parameter.BankAccountNumber,
                                                  parameter.AllocationTypeId,
                                                  parameter.Gender,
                                                  parameter.ResidenceCountryId,
                                                  parameter.BirthCountryId,
                                                  parameter.CitizenshipCountryId,
                                                  parameter.DirectoryId,
                                                  parameter.ActiveDate,
                                                  parameter.InactiveDate,
                                                  parameter.IdExpirationDate,
                                                  parameter.CommissionBehaviorId,
                                                  parameter.ExpedientId,
                                                  parameter.ReferencedBy,
                                                  parameter.ContactNotes,
                                                  parameter.HistoryNotes,
                                                  parameter.AutomaticCancellationDays,
                                                  parameter.UbicationSysflex,
                                                  parameter.SourceId,
                                                  parameter.UserId);

            result = temp.Select(x => new RepositoryResult
            {
                Action  = x.Action,
                CorpId  = x.Corp_Id,
                AgentId = x.Agent_Id
            }).FirstOrDefault();

            return
                result;
        }

        public RepositoryResult SetAgentCommunication(AgentIntegration.Communication.ComunicationData parameter)
        {
            var result = new RepositoryResult();
            var temp = _dbContext.SP_SET_EN_AGENT_ST_COMM_DETAIL(parameter.CorpId,
                                                                 parameter.DirectoryId,
                                                                 parameter.DirDetailId,
                                                                 parameter.CommTypeId,
                                                                 parameter.DirectoryTypeId,
                                                                 parameter.PhoneTypeId,
                                                                 parameter.PhonePrefix,
                                                                 parameter.AreaCode,
                                                                 parameter.PhoneNumber,
                                                                 parameter.PhoneExt,
                                                                 parameter.Address,
                                                                 parameter.PersonToContact,
                                                                 parameter.RegionId,
                                                                 parameter.CountryId,
                                                                 parameter.DomesticRegionId,
                                                                 parameter.StateProvId,
                                                                 parameter.CityId,
                                                                 parameter.AreaId,
                                                                 parameter.AddressNo,
                                                                 parameter.BlgdNumber,
                                                                 parameter.Floor,
                                                                 parameter.Door,
                                                                 parameter.NearToReference,
                                                                 parameter.ZipCode,
                                                                 parameter.IsPrimary,
                                                                 parameter.Comments,
                                                                 parameter.UsrId);

            result = temp.Select(x => new RepositoryResult
            {
                Action = x.Action,
                CorpId = x.Corp_Id,
                DirectoryId = x.Directory_Id,
                DirDetailId = x.Dir_Detail_Id,
                CommTypeId = x.Comm_Type_Id,
                DirectoryTypeId = x.Directory_Type_Id
            }).FirstOrDefault();

            return
                result;
        }

        public int SetAgentIndex(int? CorpId, int? AgentId, decimal? IndexValue, int UserId)
        {
            var temp = _dbContext.SP_SET_EN_AGENT_INDICE(CorpId, AgentId, IndexValue, UserId);
            return
                1;
        }

        public int SetPropertyAgentIndex(int? CorpId, int? AgentId, decimal? IndexValue, int UserId)
        {
            var temp = _dbContext.SP_SET_EN_AGENT_INDICE_PROPIEDAD(CorpId, AgentId, IndexValue, UserId);
            return
                1;
        }

        public RepositoryResult SetAgentUniqueMatch(Nullable<int> CorpId, Nullable<int> AgentId, Nullable<int> UniqueAgentId, string LastNumberId, Nullable<System.DateTime> DateOfBirth, int UserId)
        {
            var result = new RepositoryResult();
            var temp = _dbContext.SP_SET_EN_AGENT_UNIQUE_MATCH(CorpId, AgentId, UniqueAgentId, LastNumberId, DateOfBirth, UserId);
            result = temp.Select(x => new RepositoryResult
            {
                Action = x.Action,
                CorpId = x.Corp_Id,
                AgentId = x.Agent_Id
            }).FirstOrDefault();

            return
                result;
        }

        public RepositoryResult SetAgentLicense(AgentIntegration.License.LicenseData parameter)
        {
            var result = new RepositoryResult();
            var temp = _dbContext.SP_SET_EN_AGENT_IDS(parameter.CorpId,
                                                      parameter.AgentId,
                                                      parameter.SeqNo,
                                                      parameter.AgentIdType,
                                                      parameter.Id,
                                                      parameter.ValidDate,
                                                      parameter.ExpireDate,
                                                      parameter.RevalidationDate,
                                                      parameter.CountryId,
                                                      parameter.DocTypeId,
                                                      parameter.DocCategoryId,
                                                      parameter.DocumentId,
                                                      parameter.StatusId,
                                                      parameter.UserId
                                                      );

            result = temp.Select(x => new RepositoryResult
            {
                Action = x.Action,
                CorpId = x.Corp_Id,
                AgentId = x.Agent_Id,
                SeqNo = x.Seq_No
            }).FirstOrDefault();

            return
                result;
        }

        public RepositoryResult SetAssignedAgentOffice(AgentIntegration.AssignedOffice.OfficeData parameter)
        {
            var result = new RepositoryResult();
            var temp = _dbContext.SP_SET_EN_AGENT_ASSIGNED_OFFICE(parameter.CorpId,
                                                                  parameter.RegionId,
                                                                  parameter.CountryId,
                                                                  parameter.DomesticRegId,
                                                                  parameter.StateProvId,
                                                                  parameter.CityId,
                                                                  parameter.OfficeId,
                                                                  parameter.AgentTypeId,
                                                                  parameter.AgentId,
                                                                  parameter.AssignedDate,
                                                                  parameter.UnassignDate,
                                                                  parameter.UsrId);

            result = temp.Select(x => new RepositoryResult
            {
                Action = x.Action,
                CorpId = x.Corp_Id,
                RegionId = x.Region_Id,
                CountryId = x.Country_Id,
                DomesticRegId = x.DomesticReg_Id,
                StateProvId = x.State_Prov_Id,
                CityId = x.City_Id,
                OfficeId = x.Office_Id,
                AgentTypeId = x.Agent_Type_Id,
                AgentId = x.Agent_Id
            }).FirstOrDefault();

            return
                result;
        }

        public RepositoryResult SetAgentBusinessLine(AgentIntegration.BusinessLine.Data parameter)
        {
            var result = new RepositoryResult();
            var temp = _dbContext.SP_SET_ST_AGENT_BUSINESS_LINES(parameter.CorpId,
                                                                 parameter.RegionId,
                                                                 parameter.CountryId,
                                                                 parameter.DomesticRegId,
                                                                 parameter.StateProvId,
                                                                 parameter.CityId,
                                                                 parameter.OfficeId,
                                                                 parameter.BlTypeID,
                                                                 parameter.BlId,
                                                                 parameter.ProductId,
                                                                 parameter.AgentId,
                                                                 parameter.AgentTypeId,
                                                                 parameter.AssignedDate,
                                                                 parameter.UnassignDate,
                                                                 parameter.ActivationDate,
                                                                 parameter.InactivationDate,
                                                                 parameter.UsrId);

            result = temp.Select(x => new RepositoryResult
            {
                Action = x.Action,
                CorpId = x.Corp_Id,
                RegionId = x.Region_Id,
                CountryId = x.Country_Id,
                DomesticRegId = x.DomesticReg_Id,
                StateProvId = x.State_Prov_Id,
                CityId = x.City_Id,
                OfficeId = x.Office_Id,
                AgentId = x.Agent_Id,
                BlTypeID = x.Bl_Type_ID,
                BlId = x.Bl_Id,
                ProductId = x.Product_Id
            }).FirstOrDefault();

            return
                result;
        }

        public RepositoryResult SetAgentChainDetail(AgentIntegration.ChainDetail parameter)
        {
            var result = new RepositoryResult();
            var temp = _dbContext.SP_SET_EN_AGENT_CHAIN_DETAIL(parameter.CorpId,
                                                               parameter.ChainId,
                                                               parameter.ChainDetId,
                                                               parameter.AgentId,
                                                               parameter.OrderId,
                                                               parameter.ChainLevelId,
                                                               parameter.AgentChainStatus,
                                                               parameter.SupervisorAgentId,
                                                               parameter.RelationshipToSupervisor,
                                                               parameter.DateAssigned,
                                                               parameter.DateUnassigned,
                                                               parameter.SourceID,
                                                               parameter.UserId);

            result = temp.Select(x => new RepositoryResult
            {
                Action = x.Action,
                CorpId = x.Corp_Id,
                ChainId = x.Chain_Id,
                ChainDetId = x.Chain_Det_Id
            }).FirstOrDefault();

            return
                result;
        }

        public RepositoryResult SetAgentSalesChannel(AgentIntegration.SalesChannel parameter)
        {
            var result = new RepositoryResult();
            var temp = _dbContext.SP_SET_EN_AGENT_SALES_CHANNELS(parameter.CorpId,
                                                               parameter.AgentId,
                                                               parameter.DistributiomId,
                                                               parameter.ChannelDistribStatusId,
                                                               parameter.UserId);

            result = temp.Select(x => new RepositoryResult
            {
                Action = x.Action,
                CorpId = x.Corp_Id,
                AgentId = x.Agent_Id,
                DistributionId = x.Distribution_Id
            }).FirstOrDefault();

            return
                result;
        }

        public RepositoryResult SetAgentDocument(AgentIntegration.AgentDocument parameter)
        {
            var result = new RepositoryResult();
            var temp = _dbContext.SP_SET_EN_AGENT_DOCUMENTS(parameter.CorpId,
                                                            parameter.AgentId,
                                                            parameter.DocTypeId,
                                                            parameter.DocCategoryId,
                                                            parameter.DocumentId,
                                                            parameter.AgentDocumentStatus,
                                                            parameter.UserId);

            result = temp.Select(x => new RepositoryResult
            {
                Action = x.Action,
                CorpId = x.Corp_Id,
                AgentId = x.Agent_Id,
                DocTypeId = x.Doc_Type_Id,
                DocCategoryId = x.Doc_Category_Id,
                DocumentId = x.Document_Id
            }).FirstOrDefault();

            return
                result;
        }

        public RepositoryResult GetAgentSalesChannelLevel(int distributionId, int Bl_Id)
        {
            var result = new RepositoryResult();
            var temp = _dbContext.SP_GET_DROPDOWN_EN_AGENT_SALES_CHANNELS_LEVEL(distributionId, Bl_Id);

            result = temp.Select(x => new RepositoryResult
            {
                ChainLevelId = x.Chain_Level_Id,
                ChainlevelDesc = x.Chain_level_Desc
            }).FirstOrDefault();

            return
                result;
        }

        public List<RepositoryResult> GetOfficeBLById(int officeId)
        {
            var result = new List<RepositoryResult>();
            var temp = _dbContext.SP_GET_ST_OFFICE_BL(officeId);

            result = temp.Select(x => new RepositoryResult
            {
                CorpId = x.Corp_Id,
                RegionId = x.Region_Id,
                CountryId = x.Country_Id,
                DomesticRegId = x.DomesticReg_Id,
                StateProvId = x.State_Prov_Id,
                CityId = x.City_Id,
                OfficeId = x.Office_Id,
                BlTypeID = x.Bl_Type_ID,
                BlId = x.Bl_Id,
                ProductId = x.Product_Id
            }).ToList();

            return
                result;
        }

        public RepositoryResult GetOfficeById(int officeId)
        {
            var result = new RepositoryResult();
            var temp = _dbContext.SP_GET_ST_OFFICE(officeId);

            result = temp.Select(x => new RepositoryResult
            {
                CorpId = x.Corp_Id,
                RegionId = x.Region_Id,
                CountryId = x.Country_Id,
                DomesticRegId = x.Domesticreg_Id,
                StateProvId = x.State_Prov_Id,
                CityId = x.City_Id,
                OfficeId = x.Office_Id,
                Office_Desc = x.Office_Desc
            }).FirstOrDefault();

            return
                result;
        }

        public int GetNextDirectoryId()
        {
            var temp = _dbContext.SP_GET_NEXT_DIRECTORY_ID();
            return
                temp.FirstOrDefault().GetValueOrDefault();
        }

        public RepositoryResult GetAgentBussinessLine(int agentId)
        {
            var result = new RepositoryResult();

            int chainId = -1;

            var agentChain = _dbContext.SP_GET_EN_AGENT_CHAIN_DETAIL(1, null, null, agentId, null, null).FirstOrDefault();
            if (agentChain != null)
            {
                chainId = agentChain.Chain_Id;
            }

            var temp = _dbContext.SP_GET_EN_AGENT_CHAIN(1, chainId, null);

            result = temp.Where(a => a.Chain_Status == true).Select(x => new RepositoryResult
            {
                ChainId = x.Chain_Id,
                BussinessLineName = x.Chain_Desc

            }).FirstOrDefault();

            return
                result;
        }

        public List<RepositoryResult> GetSysflexProvince(int? provinceId)
        {
            var result = new List<RepositoryResult>();

            var country = from a in _dbContext.VW_GET_UBICACION_SYSFLEX_PAIS
                          where a.DescripcionPais == "REPUBLICA DOMINICANA"
                          select a;

            var provinces = from p in _dbContext.VW_GET_UBICACION_SYSFLEX_PROVINCIA
                            where p.CodPais == country.FirstOrDefault().CodPais
                            select p;

            var temp = provinceId.HasValue ? provinces.Where(z => z.CodProvincia == provinceId.Value).ToList() : provinces.ToList();

            result = temp.Select(x => new RepositoryResult
            {
                ProvinceId = x.CodProvincia,
                ProvinceDesc = x.DescripcionProvincia

            }).ToList();

            return
                result;
        }

        public List<RepositoryResult> GetSysflexMunicipalities(int provinceId, int? municipe)
        {
            var result = new List<RepositoryResult>();

            var Municipalities = from m in _dbContext.VW_GET_UBICACION_SYSFLEX_MUNICIPIO
                                 where m.CodProvincia == provinceId
                                 select m;

            var temp = municipe.HasValue ? Municipalities.Where(z => z.CodMunicipio == municipe.Value).ToList() : Municipalities.ToList();

            result = temp.Select(x => new RepositoryResult
            {
                MunicipeId = x.CodMunicipio,
                MunicipeDesc = x.DescripcionMunicipio

            }).ToList();

            return
                result;
        }

        public List<RepositoryResult> GetSysflexCity(int provinceId, int municipe, int? cityId)
        {
            var result = new List<RepositoryResult>();

            var cities = from c in _dbContext.VW_GET_UBICACION_SYSFLEX_SECTOR
                         where c.CodProvincia == provinceId && c.CodMunicipio == municipe
                         select c;

            var temp = cityId.HasValue ? cities.Where(z => z.Codigo == cityId.Value).ToList() : cities.ToList();

            result = temp.Select(x => new RepositoryResult
            {
                CitySysflexId = x.Codigo,
                CitySysflexDesc = x.Descripcion

            }).ToList();

            return
                result;
        }

        public RepositoryResult GetAgent(int agentId)
        {
            var result = new RepositoryResult();
            var temp = _dbContext.SP_GET_EN_AGENT(agentId);

            result = temp.Select(x => new RepositoryResult
            {
                AgentId = x.Agent_Id,
                FirstLastname = x.First_Lastname,
                FirstName = x.First_Name,
                NameId = x.Name_Id,
                AgentCode = x.Agent_Code,
                SourceId = x.Source_ID

            }).FirstOrDefault();

            return
                result;
        }

        public RepositoryResult GetAgentByNameId(string nameId)
        {
            var result = new RepositoryResult();
            var temp = _dbContext.SP_GET_EN_AGENT_AGENTID_BY_NAMEID(nameId);

            result = temp.Select(x => new RepositoryResult
            {
                AgentId = x.Agent_Id

            }).FirstOrDefault();

            return
                result;
        }

        public RepositoryResult GetAgentChangeIntermediaryPortfolio(AgentIntegration.AgentChange parameters)
        {
            var result = new RepositoryResult();
            var temp = _dbContext.SP_GET_EN_AGENT_CHANGE_INTERMEDIARY_PORTFOLIO(
                parameters.DateOut,
                parameters.DateIn,
                parameters.Note,
                parameters.User,
                parameters.NewSupervisAgentId,
                parameters.NewSupervisAgentCode,
                parameters.AgentIds,
                parameters.AgentCodes,
                parameters.ModiUser
                );

            result = temp.Select(x => new RepositoryResult
            {
                Action = x.Action

            }).FirstOrDefault();

            return
                result;
        } 
        


        public RepositoryResult GetSerachSuperVisor(int? agentid)
        {
            using (EfModel.GlobalEntities context = new EfModel.GlobalEntities())
            {

                IEnumerable<RepositoryResult> RetornarValue = context.Database.SqlQuery<RepositoryResult>("EXEC SP_VERIFICATE_OFFICES_AGENT_SUPERVISOR @agentid",
                    new System.Data.SqlClient.SqlParameter("@agentid", agentid)
                    ).ToList();
                return RetornarValue.FirstOrDefault();
            }
        }
        public RepositoryResult GetSerachAgent(int agentid, int? Office_Id)
        {
            using (EfModel.GlobalEntities context = new EfModel.GlobalEntities())
            {
                //CREAR METODO EN POS_SITE DE PRODUCCION
                IEnumerable<RepositoryResult> RetornarValue = context.Database.SqlQuery<RepositoryResult>("EXEC SP_VERIFICATE_OFFICES_AGENT @agentid,@Office_Id",
                    new System.Data.SqlClient.SqlParameter("@agentid", agentid),
                    new System.Data.SqlClient.SqlParameter("@Office_Id", Office_Id)
                    ).ToList();
                return RetornarValue.FirstOrDefault();
            }
        }
        public void UpdateOfficeAgent(int agentid, int? Office_Id)
        {
            using (EfModel.GlobalEntities context = new EfModel.GlobalEntities())
            {
                //CREAR METODO EN POS_SITE DE PRODUCCION
                IEnumerable<RepositoryResult> RetornarValue = context.Database.SqlQuery<RepositoryResult>("EXEC SP_SET_UPDATE_OFFICES_AGENT @agentid,@Office_Id",
                    new System.Data.SqlClient.SqlParameter("@agentid", agentid),
                    new System.Data.SqlClient.SqlParameter("@Office_Id", Office_Id)
                    ).ToList();
            }
        }

        public void InsertOfficeAgent(int? Corp_Id, int? Region_Id, int? Country_Id,
                                      int? DomesticReg_Id, int? State_Prov_Id, int? City_Id,
                                      int? Office_Id, int? Agent_Id)
        {
            using (EfModel.GlobalEntities context = new EfModel.GlobalEntities())
            {
                //CREAR METODO EN POS_SITE DE PRODUCCION
                IEnumerable<RepositoryResult> RetornarValue = context.Database.SqlQuery<RepositoryResult>("EXEC SP_SET_INSERT_OFFICES_AGENT @Corp_Id,@Region_Id,@Country_Id,@DomesticReg_Id,@State_Prov_Id,@City_Id,@Office_Id,@Agent_Id",
                    new System.Data.SqlClient.SqlParameter("@Corp_Id", Corp_Id),
                    new System.Data.SqlClient.SqlParameter("@Region_Id", Region_Id),
                    new System.Data.SqlClient.SqlParameter("@Country_Id", Country_Id),
                    new System.Data.SqlClient.SqlParameter("@DomesticReg_Id", DomesticReg_Id),
                    new System.Data.SqlClient.SqlParameter("@State_Prov_Id", State_Prov_Id),
                    new System.Data.SqlClient.SqlParameter("@City_Id", City_Id),
                    new System.Data.SqlClient.SqlParameter("@Office_Id", Office_Id),
                    new System.Data.SqlClient.SqlParameter("@Agent_Id", Agent_Id)
                    ).ToList();
            }
        }

        public void UpdateOfficesNetx(int? Office_Id, int? Agent_Id, int? UserModieficate)
        {
            using (EfModel.GlobalEntities context = new EfModel.GlobalEntities())
            {
                //CREAR METODO EN POS_SITE DE PRODUCCION
                IEnumerable<RepositoryResult> RetornarValue = context.Database.SqlQuery<RepositoryResult>("EXEC SP_SET_ACTIVATE_OFFICE @AgentId,@Offices,@UserModieficate",
                    new System.Data.SqlClient.SqlParameter("@AgentId", Agent_Id),
                    new System.Data.SqlClient.SqlParameter("@Offices", Office_Id),
                    new System.Data.SqlClient.SqlParameter("@UserModieficate", UserModieficate)
                    ).ToList();
            }
        }

        #region Users

        public RepositoryResult SetCreateUsersSecurityAgent(string Agent_Code, int UserId, string Email)
        {
            using (SecurityEntities db = new SecurityEntities())
            {
                //CREAR METODO EN POS_SITE DE PRODUCCION
                IEnumerable<RepositoryResult> RetornarValue = db.Database.SqlQuery<RepositoryResult>("EXEC [Security].[SP_CREATE_AGENT_FROM_AGENT_CODE_INTEGRATION]  @Agent_Code,@UserCreate,@Email",
                    new System.Data.SqlClient.SqlParameter("@Agent_Code", Agent_Code),
                    new System.Data.SqlClient.SqlParameter("@UserCreate", UserId),
                    new System.Data.SqlClient.SqlParameter("@Email", Email)

                    ).ToList();
                return RetornarValue.FirstOrDefault();
            }
        }

        public RepositoryResult UpdateUser(string Agent_Code, int UserId, int UserCreate, string Email, string UserLogin)
        {
            using (SecurityEntities db = new SecurityEntities())
            {
                //CREAR METODO EN POS_SITE DE PRODUCCION
                IEnumerable<RepositoryResult> RetornarValue = db.Database.SqlQuery<RepositoryResult>("EXEC [Security].[SP_SET_ACTUALIZAR_USUARIO_CORREO]  @Agent_Code,@UserId,@UserCreate,@Email,@UserLogin",
                    new System.Data.SqlClient.SqlParameter("@Agent_Code", Agent_Code),
                    new System.Data.SqlClient.SqlParameter("@UserId", UserId),
                    new System.Data.SqlClient.SqlParameter("@UserCreate", UserCreate),
                    new System.Data.SqlClient.SqlParameter("@Email", Email),
                     new System.Data.SqlClient.SqlParameter("@UserLogin", UserLogin)
                    ).ToList();
                return RetornarValue.FirstOrDefault();
            }
        }
        public RepositoryResult EXISTS_USER(string UserLogin)
        {
            using (SecurityEntities db = new SecurityEntities())
            {
                //CREAR METODO EN POS_SITE DE PRODUCCION
                IEnumerable<RepositoryResult> RetornarValue = db.Database.SqlQuery<RepositoryResult>("EXEC [Security].[SP_EXISTS_USER] @UserLogin",
                     new System.Data.SqlClient.SqlParameter("@UserLogin", UserLogin)
                    ).ToList();
                return RetornarValue.FirstOrDefault();
            }
        }
        #endregion
    }
}



