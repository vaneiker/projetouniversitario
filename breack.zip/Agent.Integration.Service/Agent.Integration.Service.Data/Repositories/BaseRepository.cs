﻿using Agent.Integration.Service.Data.EfModel;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agent.Integration.Service.Data.Repositories
{
    public class BaseRepository
    {
        public readonly GlobalEntities _dbContext;

        public BaseRepository(DbContext dbContext)
        {
            _dbContext = (dbContext as GlobalEntities);
        }

    }
}
