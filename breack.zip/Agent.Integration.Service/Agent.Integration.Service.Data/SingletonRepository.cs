﻿using Agent.Integration.Service.Data.EfModel;
using Agent.Integration.Service.Data.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Agent.Integration.Service.Data
{
    public sealed class SingletonRepository : IDisposable
    {
        private System.Data.Entity.DbContext _dbContext;

        private static readonly SingletonRepository singletonInstance;
        private BaseRepository _baseRepository;
        private AgentRepository _agentRepository;
        private DocumentRepository _documentRepository;

        public static SingletonRepository Instance
        {
            get
            {
                return
                    singletonInstance;
            }
        }

        public BaseRepository BaseRepository
        {
            get
            {
                if (this._baseRepository == null)
                {
                    this._baseRepository = new BaseRepository(_dbContext);
                }
                return
                    _baseRepository;
            }
        }

        public AgentRepository AgentRepository
        {
            get
            {
                if (this._agentRepository == null)
                {
                    this._agentRepository = new AgentRepository(_dbContext);
                }
                return
                    _agentRepository;
            }
        }


        public DocumentRepository DocumentRepository
        {
            get
            {
                if (this._documentRepository == null)
                {
                    this._documentRepository = new DocumentRepository(_dbContext);
                }
                return
                    _documentRepository;
            }
        }

        private SingletonRepository()
        {
            _dbContext = new GlobalEntities();
        }

        static SingletonRepository()
        {
            singletonInstance = new SingletonRepository();
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

    }
}
