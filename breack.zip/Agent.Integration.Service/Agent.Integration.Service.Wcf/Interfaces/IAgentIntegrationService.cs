﻿using Agent.Integration.Service.Logic;
using Agent.Integration.Service.Wcf.Common;
using Agent.Integration.Service.Wcf.DataContracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace Agent.Integration.Service.Wcf.Interfaces
{
    [ServiceContract]
    public interface IAgentIntegrationService
    {
        [OperationContract]
        AgentResult SetAgent(AgentInformation AgentData);

        [OperationContract]
        AgentResult SetAgentCommunication(AgentInformation.ComunicationData CommunicationData);

        [OperationContract]
        AgentResult SetAgentChanger(AgentInformation.AgentChanger AgentChanger);

        [OperationContract]
        AgentResult SetAgentCreateUsers(string AgentCode, int User, string email,int modiUser,string UserLogin);

        [OperationContract]
        AgentResult SetAgentIndex(int? AgentId, decimal? IndexValue, int UserId);

        [OperationContract]
        AgentResult SetPropertyAgentIndex(int? AgentId, decimal? IndexValue, int UserId);

        [OperationContract]
        AgentResult SetAgentUniqueMatch(Nullable<int> AgentId, Nullable<int> UniqueAgentId, string AgentIdentificationNumber, Nullable<System.DateTime> DateOfBirth, int UserId);

        [OperationContract]
        AgentResult SetAgentLicense(AgentInformation.LicenseData LicenseData);

        [OperationContract]
        AgentResult SetAssignedAgentOffice(AgentInformation.OfficeData OfficeData);

        [OperationContract]
        AgentResult SetAgentBusinessLine(AgentInformation.BusinessLine BusinessLine);

        [OperationContract]
        AgentResult SetAgentChainDetail(AgentInformation.ChainDetail ChainDetail);

        [OperationContract]
        AgentResult SetAgentSalesChannel(AgentInformation.SalesChannel SalesChannel);

        [OperationContract]
        AgentResult SetAgentDocument(AgentInformation.AgentDocument AgentDocument);

        [OperationContract]
        DocumentResult SetDocument(Document document);

  
        //[OperationContract]
        //DocumentResult SetExportedFile(ExportedFiles file);

        [OperationContract]
        Common.DocumentResult GetDocumentForAgents();

        [OperationContract]
        Common.AgentResult GetAgentBussinessLine(int agentId);

        [OperationContract]
        Common.AgentResult GetSysflexProvince(int? provinceId);

        [OperationContract]
        Common.AgentResult GetSysflexMunicipalities(int provinceId, int? municipe);

        [OperationContract]
        Common.AgentResult GetSysflexCity(int provinceId, int municipe, int? cityId);

        [OperationContract]
        Common.AgentResult SendAgentToCoreAuto(int agentId, string userName);

        [OperationContract]
        Common.AgentResult SendAgentToCoreHealth(int agentId, string userName);

        [OperationContract]
        Common.AgentResult SendAgentToCoreLife(int agentId);

        [OperationContract]
        Common.AgentResult GetAgent(int agentId);
    }
}
