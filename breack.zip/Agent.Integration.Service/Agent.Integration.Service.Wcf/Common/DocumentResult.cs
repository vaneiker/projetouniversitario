﻿using Agent.Integration.Service.Data.Repositories;
using Agent.Integration.Service.Entity.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace Agent.Integration.Service.Wcf.Common
{
    [DataContract]
    public class DocumentResult: BaseResult
    {
        [DataMember]
        public RepositoryResult ExecutionResult { get; set; }

        [DataMember]
        public List<RepositoryResult> ExecutionResultList { get; set; }
    }
}