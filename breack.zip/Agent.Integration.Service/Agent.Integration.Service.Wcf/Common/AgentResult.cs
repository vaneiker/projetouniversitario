﻿using Agent.Integration.Service.Data.Repositories;
using Agent.Integration.Service.Logic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace Agent.Integration.Service.Wcf.Common
{
    [DataContract]
    public class AgentResult: BaseResult
    {
        [DataMember]
        public RepositoryResult ExecutionResult { get; set; }
        public PrimitiveResult PrimitiveResult { get; set; }

        [DataMember]
        public List<RepositoryResult> ExecutionResultList { get; set; }
    }
}