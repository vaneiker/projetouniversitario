﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Agent.Integration.Service.Wcf.Common
{
    public static class Utilities
    {

        public static bool notNullOrEmptyOrWitheSpaces(this string value)
        {
            if (!string.IsNullOrEmpty(value) && !string.IsNullOrWhiteSpace(value))
            {
                return true;
            }
            return false;
        }
    }
}