﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace Agent.Integration.Service.Wcf.Common
{
    public enum CodeType { Ok, Error, MissingParameter }

    [DataContract]
    public class BaseResult
    {
        [DataMember]
        public string Message { get; set; }
        [DataMember]
        public CodeType Code { get; set; }
    }
}