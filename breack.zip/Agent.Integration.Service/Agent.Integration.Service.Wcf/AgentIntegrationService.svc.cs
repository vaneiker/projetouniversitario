﻿using Agent.Integration.Service.Wcf.Common;
using Agent.Integration.Service.Wcf.DataContracts;
using Agent.Integration.Service.Wcf.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.PeerResolvers;
using System.ServiceModel.Web;
using System.Text;

namespace Agent.Integration.Service.Wcf
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
    public class AgentIntegrationService : BaseService, IAgentIntegrationService
    {
        public Common.AgentResult SetAgent(AgentInformation AgentData)
        {
            var result = new Common.AgentResult();
            var ErrorList = "";

            try
            {
                int? realIdentityTypeId = (int)AgentData.IdentityTypeId;

                string agentSex = "";

                switch (AgentData.Gender.ToString())
                {
                    case "Female":
                        agentSex = "F";
                        break;
                    case "Male":
                        agentSex = "M";
                        break;
                    case "Company":
                        agentSex = "N";
                        break;
                    default:
                        agentSex = "N";
                        break;
                }


                #region Validando los parametros

                if (string.IsNullOrEmpty(AgentData.IdentificationNumber) && !AgentData.AgentId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "IdentificationNumber");
                }

                if (string.IsNullOrEmpty(AgentData.FirstName) && !AgentData.AgentId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "FirstName");
                }

                if (string.IsNullOrEmpty(AgentData.FirstLastName) && AgentData.IdentityTypeId == IdentityType.PersonaFisica && !AgentData.AgentId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "FirstLastName");
                }

                if (!AgentData.DateOfBirth.HasValue && AgentData.IdentityTypeId == IdentityType.PersonaFisica && !AgentData.AgentId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "DateOfBirth");
                }

                if (!AgentData.ExpedientId.HasValue && !AgentData.AgentId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "ExpedientId");
                }

                if (!realIdentityTypeId.HasValue && !AgentData.AgentId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "IdentityTypeId");
                }

                if (!AgentData.ActiveDate.HasValue && !AgentData.AgentId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "ActiveDate");
                }

                if (!AgentData.BirthCountryId.HasValue && AgentData.IdentityTypeId == IdentityType.PersonaFisica && !AgentData.AgentId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "BirthCountryId");
                }

                if (string.IsNullOrEmpty(agentSex) && AgentData.IdentityTypeId == IdentityType.PersonaFisica && !AgentData.AgentId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "Gender");
                }

                if (!AgentData.ResidenceCountryId.HasValue && !AgentData.AgentId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "ResidenceCountryId");
                }

                if (!AgentData.CityId.HasValue && !AgentData.AgentId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "CityId");
                }

                if (!string.IsNullOrEmpty(ErrorList))
                {
                    result.Code = Common.CodeType.MissingParameter;
                    result.Message = ErrorList;
                    return
                        result;
                }

                #endregion

                if (realIdentityTypeId == 0)
                {
                    realIdentityTypeId = null;
                }

                if (AgentData.Gender == Gender.NA)
                {
                    agentSex = null;
                }


                var data = oAgentManager.SetAgent(new Entity.Entities.AgentIntegration.Agent
                {
                    AgentId = AgentData.AgentId,
                    IdentityTypeId = realIdentityTypeId,
                    IdentificationNumber = AgentData.IdentificationNumber,
                    AgentCode = AgentData.AgentCode,
                    NameId = AgentData.NameId,
                    FirstName = AgentData.FirstName,
                    MiddleName = AgentData.MiddleName,
                    FirstLastName = AgentData.FirstLastName,
                    SecondLastname = AgentData.SecondLastname,
                    NickName = AgentData.NickName,
                    DateOfBirth = AgentData.DateOfBirth,
                    PaymentTypeId = AgentData.PaymentTypeId,
                    ABANumber = AgentData.ABANumber,
                    BankAccountNumber = AgentData.BankAccountNumber,
                    AllocationTypeId = AgentData.AllocationTypeId,
                    Gender = agentSex,
                    ResidenceCountryId = AgentData.ResidenceCountryId,
                    BirthCountryId = AgentData.BirthCountryId,
                    CitizenshipCountryId = AgentData.CityId,
                    DirectoryId = AgentData.DirectoryId,
                    ActiveDate = AgentData.ActiveDate,
                    InactiveDate = AgentData.InactiveDate,
                    IdExpirationDate = AgentData.IdExpirationDate,
                    CommissionBehaviorId = AgentData.CommissionBehaviorId,
                    ExpedientId = AgentData.ExpedientId,
                    ReferencedBy = AgentData.ReferencedBy,
                    ContactNotes = AgentData.ContactNotes,
                    HistoryNotes = AgentData.HistoryNotes,
                    AutomaticCancellationDays = AgentData.AutomaticCancellationDays,
                    UserId = AgentData.UserId.GetValueOrDefault(),
                    UbicationSysflex = AgentData.UbicationSysflex,
                    SourceId = AgentData.SourceId
                });

                if (!data.result.HasError)
                {
                    result.ExecutionResult = data.SingleResult;
                    result.Code = Common.CodeType.Ok;
                }
                else
                {
                    result.Code = Common.CodeType.Error;
                    result.Message = data.result.ErrorDescription;
                }
            }
            catch (Exception ex)
            {
                result.Code = Common.CodeType.Error;
                result.Message = ex.Message;
            }
            return
                result;
        }

        public Common.AgentResult SetAgentCommunication(AgentInformation.ComunicationData CommunicationData)
        {
            var result = new Common.AgentResult();
            var ErrorList = "";
            try
            {
                int? realCommTypeId = (int)CommunicationData.CommTypeId;
                int? realDirectoryTypeId = (int)CommunicationData.DirectoryTypeId;
                int? realPhoneTypeId = null;


                //Telefonos
                string realPhone = null;

                if (CommunicationData.CommTypeId == CommunicationTypes.Phone)
                {
                    realPhone = CommunicationData.PhoneNumber;
                    realPhoneTypeId = (int)CommunicationData.PhoneTypeId;
                }
                //

                //Direccion
                string realAddress = null;
                int? realCountryId = null;
                int? realCityId = null;

                if (CommunicationData.CommTypeId == CommunicationTypes.Address)
                {
                    realAddress = CommunicationData.Address;
                    realCountryId = CommunicationData.CountryId;
                    realCityId = CommunicationData.CityId;
                }
                //

                //Email
                if (CommunicationData.CommTypeId == CommunicationTypes.Email)
                {
                    realAddress = null;
                    realAddress = CommunicationData.Address;
                }
                //

                #region Validando los parametros

                if (!realCommTypeId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "CommTypeId");
                }

                if (!realDirectoryTypeId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "DirectoryTypeId");
                }

                if (string.IsNullOrEmpty(CommunicationData.PhoneNumber) && CommunicationData.CommTypeId == CommunicationTypes.Phone)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "PhoneNumber");
                }

                if (string.IsNullOrEmpty(CommunicationData.Address) && CommunicationData.CommTypeId == CommunicationTypes.Address)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "Address");
                }

                if (!CommunicationData.CountryId.HasValue && CommunicationData.CommTypeId == CommunicationTypes.Address)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "CountryId");
                }

                if (!CommunicationData.CityId.HasValue && CommunicationData.CommTypeId == CommunicationTypes.Address)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "CityId");
                }


                if (!string.IsNullOrEmpty(ErrorList))
                {
                    result.Code = Common.CodeType.MissingParameter;
                    result.Message = ErrorList;
                    return
                        result;
                }

                #endregion

                int directoryId = CommunicationData.DirectoryId.GetValueOrDefault();
                if (CommunicationData.DirectoryId == null)
                {
                    directoryId = (int)oAgentManager.GetNextDirectoryId().primitiveResult.Result;
                }

                var data = oAgentManager.SetAgentCommunication(new Entity.Entities.AgentIntegration.Communication.ComunicationData
                {
                    CorpId = 1,
                    DirectoryId = directoryId,
                    DirDetailId = CommunicationData.DirDetailId,
                    CommTypeId = realCommTypeId,
                    DirectoryTypeId = realDirectoryTypeId,
                    PhoneTypeId = realPhoneTypeId,
                    PhoneNumber = realPhone,
                    Address = realAddress,
                    CountryId = realCountryId,
                    CityId = realCityId,
                    IsPrimary = CommunicationData.IsPrimary,
                    UsrId = CommunicationData.UsrId
                });

                if (!data.result.HasError)
                {
                    result.ExecutionResult = data.SingleResult;
                    result.Code = Common.CodeType.Ok;
                }
                else
                {
                    result.Code = Common.CodeType.Error;
                    result.Message = data.result.ErrorDescription;
                }
            }
            catch (Exception ex)
            {
                result.Code = Common.CodeType.Error;
                result.Message = ex.Message;
            }
            return
                result;
        }

        public Common.AgentResult SetAgentIndex(int? AgentId, decimal? IndexValue, int UserId)
        {
            var result = new AgentResult();
            var ErrorList = "";
            try
            {
                #region Validando los parametros

                if (!AgentId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "AgentId");
                }

                if (IndexValue.HasValue && IndexValue.Value <= 0)
                {
                    ErrorList += string.Format("El campo {0} debe ser mayor a cero (0). \n", "IndexValue");
                }


                if (!string.IsNullOrEmpty(ErrorList))
                {
                    result.Code = Common.CodeType.MissingParameter;
                    result.Message = ErrorList;
                    return
                        result;
                }
                #endregion

                var data = oAgentManager.SetAgentIndex(1, AgentId, IndexValue, UserId);

                if (!data.result.HasError)
                {
                    result.PrimitiveResult = data.primitiveResult;
                    result.Code = Common.CodeType.Ok;
                }
                else
                {
                    result.Code = Common.CodeType.Error;
                    result.Message = data.result.ErrorDescription;
                }
            }
            catch (Exception ex)
            {
                result.Code = Common.CodeType.Error;
                result.Message = ex.Message;
            }
            return
                result;
        }

        public Common.AgentResult SetPropertyAgentIndex(int? AgentId, decimal? IndexValue, int UserId)
        {
            var result = new AgentResult();
            var ErrorList = "";
            try
            {

                #region Validando los parametros

                if (!AgentId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "AgentId");
                }

                if (IndexValue.HasValue && IndexValue.Value <= 0)
                {
                    ErrorList += string.Format("El campo {0} debe ser mayor a cero (0). \n", "IndexValue");
                }

                if (!string.IsNullOrEmpty(ErrorList))
                {
                    result.Code = Common.CodeType.MissingParameter;
                    result.Message = ErrorList;
                    return
                        result;
                }
                #endregion

                var data = oAgentManager.SetPropertyAgentIndex(1, AgentId, IndexValue, UserId);

                if (!data.result.HasError)
                {
                    result.PrimitiveResult = data.primitiveResult;
                    result.Code = Common.CodeType.Ok;
                }
                else
                {
                    result.Code = Common.CodeType.Error;
                    result.Message = data.result.ErrorDescription;
                }
            }
            catch (Exception ex)
            {
                result.Code = Common.CodeType.Error;
                result.Message = ex.Message;
            }
            return
                result;
        }

        public Common.AgentResult SetAgentUniqueMatch(int? AgentId, int? UniqueAgentId, string AgentIdentificationNumber, DateTime? DateOfBirth, int UserId)
        {
            var result = new Common.AgentResult();
            var ErrorList = "";
            try
            {

                #region Validando los parametros

                if (!AgentId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "AgentId");
                }

                if (string.IsNullOrEmpty(AgentIdentificationNumber))
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "LastNumberId");
                }

                if (!DateOfBirth.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "DateOfBirth");
                }

                if (!string.IsNullOrEmpty(ErrorList))
                {
                    result.Code = Common.CodeType.MissingParameter;
                    result.Message = ErrorList;
                    return
                        result;
                }

                #endregion

                string ID = AgentIdentificationNumber.Replace("-", "").Replace(".", "");
                if (ID.Length >= 6)
                {
                    AgentIdentificationNumber = ID.Substring(ID.Length - 6);
                }
                else
                {
                    AgentIdentificationNumber = ID;
                }

                var data = oAgentManager.SetAgentUniqueMatch(1, AgentId, UniqueAgentId, AgentIdentificationNumber, DateOfBirth, UserId);

                if (!data.result.HasError)
                {
                    result.ExecutionResult = data.SingleResult;
                    result.Code = Common.CodeType.Ok;
                }
                else
                {
                    result.Code = Common.CodeType.Error;
                    result.Message = data.result.ErrorDescription;
                }
            }
            catch (Exception ex)
            {
                result.Code = Common.CodeType.Error;
                result.Message = ex.Message;
            }
            return
                result;
        }

        public Common.AgentResult SetAgentLicense(AgentInformation.LicenseData LicenseData)
        {
            var result = new Common.AgentResult();
            var ErrorList = "";
            try
            {
                int? realDocCategoryId = (int)LicenseData.DocCategoryId;
                int? realDocumentId = null;

                if (LicenseData.DocCategoryId == SuperintendenceLicencesID.Corridors)
                {
                    realDocumentId = (int)SuperintendenceLicencesDocumentId.Corridors;
                }
                else if (LicenseData.DocCategoryId == SuperintendenceLicencesID.Intermediaries)
                {
                    realDocumentId = (int)SuperintendenceLicencesDocumentId.Intermediaries;
                }
                else if (LicenseData.DocCategoryId == SuperintendenceLicencesID.DriverLicence)
                {
                    realDocumentId = (int)SuperintendenceLicencesDocumentId.DriverLicence;
                }
                else if (LicenseData.DocCategoryId == SuperintendenceLicencesID.NA)
                {
                    realDocumentId = (int)SuperintendenceLicencesDocumentId.NA;
                }

                #region Validando los parametros

                if (!LicenseData.AgentId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "AgentId");
                }

                if (string.IsNullOrEmpty(LicenseData.Id))
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "Id");
                }

                if (!LicenseData.CountryId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "CountryId");
                }

                if (!LicenseData.ValidDate.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "ValidDate");
                }

                if (!LicenseData.ExpireDate.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "ExpireDate");
                }

                if (!string.IsNullOrEmpty(ErrorList))
                {
                    result.Code = Common.CodeType.MissingParameter;
                    result.Message = ErrorList;
                    return
                        result;
                }
                #endregion

                var data = oAgentManager.SetAgentLicense(new Entity.Entities.AgentIntegration.License.LicenseData
                {
                    CorpId = 1,
                    AgentId = LicenseData.AgentId,
                    Id = LicenseData.Id,
                    ValidDate = LicenseData.ValidDate,
                    ExpireDate = LicenseData.ExpireDate,
                    RevalidationDate = LicenseData.RevalidationDate,
                    CountryId = LicenseData.CountryId,
                    DocTypeId = 1,
                    DocCategoryId = realDocCategoryId,
                    DocumentId = realDocumentId,
                    StatusId = true,
                    UserId = LicenseData.UserId
                });

                if (!data.result.HasError)
                {
                    result.ExecutionResult = data.SingleResult;
                    result.Code = Common.CodeType.Ok;
                }
                else
                {
                    result.Code = Common.CodeType.Error;
                    result.Message = data.result.ErrorDescription;
                }
            }
            catch (Exception ex)
            {
                result.Code = Common.CodeType.Error;
                result.Message = ex.Message;
            }
            return
                result;
        }

        public Common.AgentResult SetAgentSalesChannel(AgentInformation.SalesChannel SalesChannel)
        {
            var result = new Common.AgentResult();
            var ErrorList = "";
            try
            {
                #region Validando los parametros

                if (!SalesChannel.AgentId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "AgentId");
                }

                if (!SalesChannel.DistributionId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "DistributionId");
                }

                if (!string.IsNullOrEmpty(ErrorList))
                {
                    result.Code = Common.CodeType.MissingParameter;
                    result.Message = ErrorList;
                    return
                        result;
                }

                #endregion

                var data = oAgentManager.SetAgentSalesChannel(new Entity.Entities.AgentIntegration.SalesChannel
                {
                    CorpId = 1,
                    AgentId = SalesChannel.AgentId.GetValueOrDefault(),
                    DistributiomId = SalesChannel.DistributionId.GetValueOrDefault(),
                    ChannelDistribStatusId = true,
                    UserId = SalesChannel.UserId.GetValueOrDefault()
                });

                if (!data.result.HasError)
                {
                    result.ExecutionResult = data.SingleResult;
                    result.Code = Common.CodeType.Ok;
                }
                else
                {
                    result.Code = Common.CodeType.Error;
                    result.Message = data.result.ErrorDescription;
                }
            }
            catch (Exception ex)
            {
                result.Code = Common.CodeType.Error;
                result.Message = ex.Message;
            }
            return
                result;
        }

        public Common.AgentResult SetAgentChainDetail(AgentInformation.ChainDetail ChainDetail)
        {
            var result = new Common.AgentResult();
            var ErrorList = "";
            try
            {
                int? realBussinessLine = (int)ChainDetail.BussinessLine;
                int? realChainId = (int)ChainDetail.ChainId;

                #region Validando los parametros

                if (!ChainDetail.AgentId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "AgentId");
                }

                if (!ChainDetail.DistributionId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "DistributionId");
                }

                if (!realBussinessLine.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "BussinessLine");
                }

                if (!realChainId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "ChainId");
                }

                if (!ChainDetail.SupervisorAgentId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "SupervisorAgentId");
                }

                if (!ChainDetail.DateAssigned.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "DateAssigned");
                }

                if (!string.IsNullOrEmpty(ErrorList))
                {
                    result.Code = Common.CodeType.MissingParameter;
                    result.Message = ErrorList;
                    return
                        result;
                }

                #endregion


                var channelLevel = oAgentManager.GetAgentSalesChannelLevel(ChainDetail.DistributionId.GetValueOrDefault(), realBussinessLine.GetValueOrDefault());

                int? realChainLevelId = channelLevel.SingleResult.ChainLevelId;

                var data = oAgentManager.SetAgentChainDetail(new Entity.Entities.AgentIntegration.ChainDetail
                {
                    CorpId = 1,
                    ChainId = realChainId,
                    ChainDetId = ChainDetail.ChainDetId,
                    AgentId = ChainDetail.AgentId,
                    OrderId = 4,
                    ChainLevelId = realChainLevelId,
                    AgentChainStatus = ChainDetail.AgentChainStatus,
                    SupervisorAgentId = ChainDetail.SupervisorAgentId,
                    RelationshipToSupervisor = 0,
                    DateAssigned = ChainDetail.DateAssigned,
                    DateUnassigned = ChainDetail.DateUnassigned,
                    UserId = ChainDetail.UserId
                });

                if (!data.result.HasError)
                {
                    result.ExecutionResult = data.SingleResult;
                    result.Code = Common.CodeType.Ok;
                }
                else
                {
                    result.Code = Common.CodeType.Error;
                    result.Message = data.result.ErrorDescription;
                }
            }
            catch (Exception ex)
            {
                result.Code = Common.CodeType.Error;
                result.Message = ex.Message;
            }
            return
                result;
        }

        public Common.AgentResult SetAgentBusinessLine(AgentInformation.BusinessLine BusinessLine)
        {
            var result = new Common.AgentResult();
            var ErrorList = "";
            try
            {
                #region Validando los parametros

                if (!BusinessLine.AgentId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "AgentId");
                }

                if (!BusinessLine.OfficeId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "OfficeId");
                }

                if (!string.IsNullOrEmpty(ErrorList))
                {
                    result.Code = Common.CodeType.MissingParameter;
                    result.Message = ErrorList;
                    return
                        result;
                }

                #endregion

                int CorpId = 0;
                int RegionId = 0;
                int CountryId = 0;
                int DomesticRegId = 0;
                int StateProvId = 0;
                int CityId = 0;
                int BlTypeID = 0;
                int BlId = 0;
                int ProductId = 0;
                System.DateTime AssignedDate = DateTime.Now;
                System.DateTime UnassignDate = DateTime.Now;
                System.DateTime ActivationDate = DateTime.Now;
                System.DateTime InactivationDate = DateTime.Now;

                var officeBls = oAgentManager.GetOfficeBLById(BusinessLine.OfficeId.GetValueOrDefault());
                if (officeBls.dataResult.Count() > 0)
                {
                    foreach (var item in officeBls.dataResult)
                    {
                        CorpId = item.CorpId.GetValueOrDefault();
                        RegionId = item.RegionId.GetValueOrDefault();
                        CountryId = item.CountryId.GetValueOrDefault();
                        DomesticRegId = item.DomesticRegId.GetValueOrDefault();
                        StateProvId = item.StateProvId.GetValueOrDefault();
                        CityId = item.CityId.GetValueOrDefault();
                        BlTypeID = item.BlTypeID.GetValueOrDefault();
                        BlId = item.BlId.GetValueOrDefault();
                        ProductId = item.ProductId.GetValueOrDefault();

                        var data = oAgentManager.SetAgentBusinessLine(new Entity.Entities.AgentIntegration.BusinessLine.Data
                        {
                            CorpId = CorpId,
                            RegionId = RegionId,
                            CountryId = CountryId,
                            DomesticRegId = DomesticRegId,
                            StateProvId = StateProvId,
                            CityId = CityId,
                            OfficeId = BusinessLine.OfficeId,
                            BlTypeID = BlTypeID,
                            BlId = BlId,
                            ProductId = ProductId,
                            AgentId = BusinessLine.AgentId,
                            AgentTypeId = 3,
                            AssignedDate = AssignedDate,
                            UnassignDate = UnassignDate,
                            ActivationDate = ActivationDate,
                            InactivationDate = InactivationDate,
                            UsrId = BusinessLine.UsrId
                        });

                        if (!data.result.HasError)
                        {
                            result.ExecutionResult = data.SingleResult;
                            result.Code = Common.CodeType.Ok;
                        }
                        else
                        {
                            result.Code = Common.CodeType.Error;
                            result.Message = data.result.ErrorDescription;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                result.Code = Common.CodeType.Error;
                result.Message = ex.Message;
            }

            return
                result;
        }

        public Common.AgentResult SetAssignedAgentOffice(AgentInformation.OfficeData OfficeData)
        {
            var result = new Common.AgentResult();
            var ErrorList = "";
            try
            {

                #region Validando los parametros

                if (!OfficeData.AgentId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "AgentId");
                }

                if (!OfficeData.OfficeId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "OfficeId");
                }

                if (!string.IsNullOrEmpty(ErrorList))
                {
                    result.Code = Common.CodeType.MissingParameter;
                    result.Message = ErrorList;
                    return
                        result;
                }

                #endregion

                int CorpId = 0;
                int RegionId = 0;
                int CountryId = 0;
                int DomesticRegId = 0;
                int StateProvId = 0;
                int CityId = 0;

                var office = oAgentManager.GetOfficeById(OfficeData.OfficeId.GetValueOrDefault());
                if (office.SingleResult != null)
                {
                    CorpId = office.SingleResult.CorpId.GetValueOrDefault();
                    RegionId = office.SingleResult.RegionId.GetValueOrDefault();
                    CountryId = office.SingleResult.CountryId.GetValueOrDefault();
                    DomesticRegId = office.SingleResult.DomesticRegId.GetValueOrDefault();
                    StateProvId = office.SingleResult.StateProvId.GetValueOrDefault();
                    CityId = office.SingleResult.CityId.GetValueOrDefault();

                    var data = oAgentManager.SetAssignedAgentOffice(new Entity.Entities.AgentIntegration.AssignedOffice.OfficeData
                    {
                        CorpId = CorpId,
                        RegionId = RegionId,
                        CountryId = CountryId,
                        DomesticRegId = DomesticRegId,
                        StateProvId = StateProvId,
                        CityId = CityId,
                        OfficeId = OfficeData.OfficeId,
                        AgentTypeId = 3,
                        AgentId = OfficeData.AgentId,
                        AssignedDate = OfficeData.AssignedDate,
                        UnassignDate = OfficeData.UnassignDate,
                        UsrId = OfficeData.UsrId
                    });

                    if (!data.result.HasError)
                    {
                        result.ExecutionResult = data.SingleResult;
                        result.Code = Common.CodeType.Ok;
                    }
                    else
                    {
                        result.Code = Common.CodeType.Error;
                        result.Message = data.result.ErrorDescription;
                    }
                }
            }
            catch (Exception ex)
            {
                result.Code = Common.CodeType.Error;
                result.Message = ex.Message;
            }

            return
                result;
        }

        public Common.AgentResult SetAgentDocument(AgentInformation.AgentDocument AgentDocument)
        {
            var result = new Common.AgentResult();
            var ErrorList = "";

            try
            {
                #region Validando los parametros
                if (AgentDocument.AgentId <= 0)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "AgentId");
                }

                if (!string.IsNullOrEmpty(ErrorList))
                {
                    result.Code = Common.CodeType.MissingParameter;
                    result.Message = ErrorList;
                    return
                        result;
                }

                #endregion

                var data = oAgentManager.SetAgentDocument(new Entity.Entities.AgentIntegration.AgentDocument
                {
                    CorpId = 1,
                    AgentId = AgentDocument.AgentId,
                    DocTypeId = AgentDocument.DocTypeId,
                    DocCategoryId = AgentDocument.DocCategoryId,
                    DocumentId = AgentDocument.DocumentId,
                    AgentDocumentStatus = true,
                    UserId = AgentDocument.UserId
                });

                if (!data.result.HasError)
                {
                    result.ExecutionResult = data.SingleResult;
                    result.Code = Common.CodeType.Ok;
                }
                else
                {
                    result.Code = Common.CodeType.Error;
                    result.Message = data.result.ErrorDescription;
                }
            }
            catch (Exception ex)
            {
                result.Code = Common.CodeType.Error;
                result.Message = ex.Message;
            }
            return
                result;
        }

        public Common.DocumentResult SetDocument(Document document)
        {
            var result = new Common.DocumentResult();
            var ErrorList = "";
            try
            {

                #region Validando los parametros

                if (!document.DocTypeId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "DocTypeId");
                }

                if (!document.DocCategoryId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "DocCategoryId");
                }

                if (!document.DocumentBinary.Any())
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "DocumentBinary");
                }

                if (string.IsNullOrEmpty(document.DocumentName))
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "DocumentName");
                }


                if (!string.IsNullOrEmpty(ErrorList))
                {
                    result.Code = Common.CodeType.MissingParameter;
                    result.Message = ErrorList;
                    return
                        result;
                }

                #endregion

                var data = oDocumentManager.SetDocument(new Entity.Entities.Document
                {
                    DocTypeId = document.DocTypeId,
                    DocCategoryId = document.DocCategoryId,
                    DocumentId = document.DocumentId,
                    DocumentBinary = document.DocumentBinary,
                    DocumentName = document.DocumentName,
                    FileCreationDate = DateTime.Now,
                    FileExpireDate = DateTime.Now,
                    userId = document.userId.GetValueOrDefault()
                });

                if (!data.result.HasError)
                {
                    result.ExecutionResult = data.SingleResult;
                    result.Code = Common.CodeType.Ok;
                }
                else
                {
                    result.Code = Common.CodeType.Error;
                    result.Message = data.result.ErrorDescription;
                }
            }
            catch (Exception ex)
            {
                result.Code = Common.CodeType.Error;
                result.Message = ex.Message;
            }
            return
                result;
        }

        public Common.DocumentResult SetExportedFile(ExportedFiles file)
        {
            var result = new Common.DocumentResult();
            var ErrorList = "";
            try
            {

                #region Validando los parametros
                if (!file.DocTypeId.HasValue)
                    ErrorList += "Debe indicar el tipo del documento. \n";

                if (!file.DocCategoryId.HasValue)
                    ErrorList += "Debe indicar la categoria del documento. \n";

                if (!file.ExportedFilesId.HasValue)
                    ErrorList += "Debe indicar el id del archivo. \n";

                if (file.AgentId.HasValue)
                    ErrorList += "Debe indicar el id del agente. \n";

                if (!string.IsNullOrEmpty(file.DocumentName))
                    ErrorList += "Debe indicar el nombre del archivo. \n";

                if (!string.IsNullOrEmpty(ErrorList))
                {
                    result.Code = Common.CodeType.MissingParameter;
                    result.Message = ErrorList;
                    return
                        result;
                }
                #endregion

                var data = oDocumentManager.SetExportedFile(new Entity.Entities.Document.ExportedFiles
                {
                    ExportedFilesId = file.ExportedFilesId,
                    AgentId = file.AgentId,
                    DocTypeId = file.DocTypeId,
                    DocCategoryId = file.DocCategoryId,
                    DocumentId = file.DocumentId,
                    DocumentName = file.DocumentName,
                    ExportedDate = file.ExportedDate,
                    UserId = file.UserId.GetValueOrDefault(),
                });

                if (!data.result.HasError)
                {
                    result.ExecutionResult = data.SingleResult;
                    result.Code = Common.CodeType.Ok;
                }
                else
                {
                    result.Code = Common.CodeType.Error;
                    result.Message = data.result.ErrorDescription;
                }
            }
            catch (Exception ex)
            {
                result.Code = Common.CodeType.Error;
                result.Message = ex.Message;
            }
            return
                result;
        }

        public Common.DocumentResult GetDocumentForAgents()
        {
            var result = new Common.DocumentResult();
            try
            {
                var data = oDocumentManager.GetDocumentForAgents();

                if (!data.result.HasError)
                {
                    result.ExecutionResultList = data.dataResult.ToList();
                    result.Code = Common.CodeType.Ok;
                }
                else
                {
                    result.Code = Common.CodeType.Error;
                    result.Message = data.result.ErrorDescription;
                }
            }
            catch (Exception ex)
            {
                result.Code = Common.CodeType.Error;
                result.Message = ex.Message;
            }
            return
                result;
        }

        public Common.AgentResult GetAgentBussinessLine(int agentId)
        {
            var result = new Common.AgentResult();

            try
            {
                var data = oAgentManager.GetAgentBussinessLine(agentId);

                if (!data.result.HasError)
                {
                    var ddr = data.SingleResult;

                    if (ddr.ChainId == (int)ChainCodes.Auto)
                    {
                        ddr.BussinessLineName = ChainCodes.Auto.ToString();
                    }

                    if (ddr.ChainId == (int)ChainCodes.Life)
                    {
                        ddr.BussinessLineName = ChainCodes.Life.ToString();
                    }

                    if (ddr.ChainId == (int)ChainCodes.Health)
                    {
                        ddr.BussinessLineName = ChainCodes.Health.ToString();
                    }

                    ddr.ChainId = -1;

                    data.SingleResult = ddr;

                    result.ExecutionResult = data.SingleResult;
                    result.Code = Common.CodeType.Ok;
                }
                else
                {
                    result.Code = Common.CodeType.Error;
                    result.Message = data.result.ErrorDescription;
                }
            }
            catch (Exception ex)
            {
                result.Code = Common.CodeType.Error;
                result.Message = ex.Message;
            }
            return
                result;
        }

        public Common.AgentResult GetSysflexProvince(int? provinceId)
        {
            var result = new Common.AgentResult();
            try
            {
                var data = oAgentManager.GetSysflexProvince(provinceId);

                if (!data.result.HasError)
                {
                    result.ExecutionResultList = data.dataResult.ToList();
                    result.Code = Common.CodeType.Ok;
                }
                else
                {
                    result.Code = Common.CodeType.Error;
                    result.Message = data.result.ErrorDescription;
                }
            }
            catch (Exception ex)
            {
                result.Code = Common.CodeType.Error;
                result.Message = ex.Message;
            }
            return
                result;
        }

        public Common.AgentResult GetSysflexMunicipalities(int provinceId, int? municipe)
        {
            var result = new Common.AgentResult();
            try
            {
                var data = oAgentManager.GetSysflexMunicipalities(provinceId, municipe);

                if (!data.result.HasError)
                {
                    result.ExecutionResultList = data.dataResult.ToList();
                    result.Code = Common.CodeType.Ok;
                }
                else
                {
                    result.Code = Common.CodeType.Error;
                    result.Message = data.result.ErrorDescription;
                }
            }
            catch (Exception ex)
            {
                result.Code = Common.CodeType.Error;
                result.Message = ex.Message;
            }
            return
                result;
        }

        public Common.AgentResult GetSysflexCity(int provinceId, int municipe, int? cityId)
        {
            var result = new Common.AgentResult();
            try
            {
                var data = oAgentManager.GetSysflexCity(provinceId, municipe, cityId);

                if (!data.result.HasError)
                {
                    result.ExecutionResultList = data.dataResult.ToList();
                    result.Code = Common.CodeType.Ok;
                }
                else
                {
                    result.Code = Common.CodeType.Error;
                    result.Message = data.result.ErrorDescription;
                }
            }
            catch (Exception ex)
            {
                result.Code = Common.CodeType.Error;
                result.Message = ex.Message;
            }
            return
                result;
        }

        public Common.AgentResult SendAgentToCoreAuto(int agentId, string userName)
        {
            var result = new Common.AgentResult();

            try
            {
                bool inserto = oAgentService.setAgentDataOnSysFlex(agentId, userName);

                if (inserto)
                {
                    var agentData = oAgentManager.GetAgent(agentId);

                    var resultA = new Common.AgentResult();
                    resultA.ExecutionResult = agentData.SingleResult;
                    resultA.Code = Common.CodeType.Ok;

                    SetNameIDSysflex(resultA);


                    var xx = new Logic.PrimitiveResult();
                    xx.Result = inserto;
                    result.PrimitiveResult = xx;
                    result.Code = Common.CodeType.Ok;
                }
                else
                {
                    result.Code = Common.CodeType.Error;
                    result.Message = "Agente no Insertado en el core de Auto";
                }
            }
            catch (Exception ex)
            {
                result.Code = Common.CodeType.Error;
                result.Message = ex.Message;
            }

            return result;
        }

        public Common.AgentResult SendAgentToCoreHealth(int agentId, string userName)
        {
            var result = new Common.AgentResult();

            try
            {
                bool inserto = oAgentService.setAgentDataOnSysFlex(agentId, userName);

                if (inserto)
                {
                    //cambiando el sourceid
                    var sourceidSalud = getSourceIDByAgent(agentId);
                    UpdateSourceIDAgentHealth(agentId);
                    //

                    var agentData = oAgentManager.GetAgent(agentId);
                    var resultA = new Common.AgentResult();
                    resultA.ExecutionResult = agentData.SingleResult;
                    resultA.Code = Common.CodeType.Ok;
                    SetNameIDSysflex(resultA);


                    var xx = new Logic.PrimitiveResult();
                    xx.Result = inserto;
                    result.PrimitiveResult = xx;
                    result.Code = Common.CodeType.Ok;
                }
                else
                {
                    result.Code = Common.CodeType.Error;
                    result.Message = "Agente no Insertado en el core de Salud";
                }
            }
            catch (Exception ex)
            {
                result.Code = Common.CodeType.Error;
                result.Message = ex.Message;
            }

            return result;
        }

        public Common.AgentResult SendAgentToCoreLife(int agentId)
        {
            var result = new Common.AgentResult();

            try
            {
                //Antes de enviarlo a advisor debo verificar si el agente ya tienen un nameid que indicaria que ya esta en advisor
                var existe = getNameidByAgent(agentId);
                var sourceidVida = getSourceIDByAgent(agentId);

                string sourceCorrecto = "";
                if (!string.IsNullOrEmpty(sourceidVida) && sourceidVida.Contains("ATL-"))
                {
                    sourceCorrecto = sourceidVida;
                }

                System.Xml.XmlDocument xmlDoc = new System.Xml.XmlDocument();

                if (!string.IsNullOrEmpty(sourceCorrecto))
                {
                    var xmlData = oAgentServiceAdvisor.updateExistingAgent(existe);
                    xmlDoc.LoadXml(xmlData);

                    var errors = xmlDoc.GetElementsByTagName("errors");
                    if (errors.Count > 0 && !String.IsNullOrEmpty(errors[0].InnerText))
                    {
                        result.Code = Common.CodeType.Error;
                        result.Message = "Agente no Insertado en el core de Vida - " + errors[0].InnerText;

                        return result;
                    }

                    var message = xmlDoc.GetElementsByTagName("message");
                    string resultad = message.Item(0).InnerText;
                    if (!string.IsNullOrEmpty(resultad))
                    {
                        string[] sp = resultad.Split(',');
                        string sourceid = "";
                        string nameid = "";

                        if (sp.Count() > 1)
                        {
                            nameid = sp[0].ToUpper();
                            sourceid = "ATL-" + sp[1].ToUpper();
                        }
                        else
                        {
                            nameid = sp[0];
                        }

                        SetNameIDLife(agentId, nameid, sourceid);
                    }
                }
                else
                {
                    var xmlData = oAgentServiceAdvisor.addNewAgent(agentId, true);

                    xmlDoc.LoadXml(xmlData);

                    var errors = xmlDoc.GetElementsByTagName("errors");
                    if (errors.Count > 0 && !String.IsNullOrEmpty(errors[0].InnerText))
                    {
                        result.Code = Common.CodeType.Error;
                        result.Message = "Agente no Insertado en el core de Vida - " + errors[0].InnerText;

                        return result;
                    }

                    var message = xmlDoc.GetElementsByTagName("message");
                    string resultad = message.Item(0).InnerText;
                    if (!string.IsNullOrEmpty(resultad))
                    {
                        string[] sp = resultad.Split(',');
                        string sourceid = "";
                        string nameid = "";

                        if (sp.Count() > 1)
                        {
                            nameid = sp[0].ToUpper();
                            sourceid = "ATL-" + sp[1].ToUpper();
                        }

                        SetNameIDLife(agentId, nameid, sourceid);
                    }
                }

                var xx = new Logic.PrimitiveResult();
                xx.Result = true;
                result.PrimitiveResult = xx;
                result.Code = Common.CodeType.Ok;
            }
            catch (Exception ex)
            {
                result.Code = Common.CodeType.Error;
                result.Message = ex.Message;
            }

            return result;
        }

        public Common.AgentResult GetAgent(int agentId)
        {
            var result = new Common.AgentResult();
            var ErrorList = "";
            try
            {
                #region Validando los parametros

                if (agentId <= 0)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "agentId");
                }

                if (!string.IsNullOrEmpty(ErrorList))
                {
                    result.Code = Common.CodeType.MissingParameter;
                    result.Message = ErrorList;
                    return
                        result;
                }

                #endregion


                var agendData = oAgentManager.GetAgent(agentId);

                if (!agendData.result.HasError)
                {
                    result.ExecutionResult = agendData.SingleResult;
                    result.Code = Common.CodeType.Ok;
                }
                else
                {
                    result.Code = Common.CodeType.Error;
                    result.Message = agendData.result.ErrorDescription;
                }
            }
            catch (Exception ex)
            {
                result.Code = Common.CodeType.Error;
                result.Message = ex.Message;
            }
            return
                result;
        }

        public AgentResult SetAgentChanger(AgentInformation.AgentChanger AgentChanger)
        {
            var result = new Common.AgentResult();
            var ErrorList = "";
            try
            {

                #region Validando los parametros            

                if (string.IsNullOrEmpty(AgentChanger.Note))
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "Note");
                }

                if (string.IsNullOrEmpty(AgentChanger.User))
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "User");
                }

                if (!AgentChanger.NewSupervisAgentCode.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "NewSupervisAgentCode");
                }

                if (!AgentChanger.NewSupervisAgentId.HasValue)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "NewSupervisAgentId");
                }

                if (string.IsNullOrWhiteSpace(AgentChanger.AgentCodes))
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "AgentCodes");
                }

                if (string.IsNullOrWhiteSpace(AgentChanger.AgentIds))
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "AgentIds");
                }
                if (AgentChanger.ModiUser == null)
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "ModiUser");
                }


                if (!string.IsNullOrEmpty(ErrorList))
                {
                    result.Code = Common.CodeType.MissingParameter;
                    result.Message = ErrorList;
                    return
                        result;
                }

                #endregion


                var data = oAgentManager.SetAgentChangeIntermediaryPortfolio(new Entity.Entities.AgentIntegration.AgentChange
                {
                    DateOut = AgentChanger.DateOut,
                    DateIn = AgentChanger.DateIn,
                    Note = AgentChanger.Note,
                    User = AgentChanger.User,
                    NewSupervisAgentId = AgentChanger.NewSupervisAgentId,
                    NewSupervisAgentCode = AgentChanger.NewSupervisAgentCode,
                    AgentIds = AgentChanger.AgentIds,
                    AgentCodes = AgentChanger.AgentCodes,
                    ModiUser = AgentChanger.ModiUser,

                });

                if (!data.result.HasError)
                {
                    result.ExecutionResult = data.SingleResult;
                    result.Code = Common.CodeType.Ok;
                }
                else
                {
                    result.Code = Common.CodeType.Error;
                    result.Message = data.result.ErrorDescription;
                }
            }
            catch (Exception ex)
            {
                result.Code = Common.CodeType.Error;
                result.Message = ex.Message;
            }
            return
                result;
        }

        public AgentResult SetAgentCreateUsers(string AgentCode, int User, string email, int UserModificate, string UserLogin = "")
        {
            var result = new Common.AgentResult();
            var ErrorList = "";
            try
            {

                #region Validando los parametros   

                if (string.IsNullOrWhiteSpace(AgentCode))
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "AgentCode");
                }
                if (string.IsNullOrWhiteSpace(email))
                {
                    ErrorList += string.Format("El campo {0} es requerido. \n", "Email");
                }

                if (!string.IsNullOrEmpty(ErrorList))
                {
                    result.Code = Common.CodeType.MissingParameter;
                    result.Message = ErrorList;
                    return
                        result;
                }
                #endregion
                var data = oAgentManager.SetCreateUsersSecurityAgent(AgentCode, User, email, UserModificate, UserLogin);

                if (!data.result.HasError)
                {
                    result.ExecutionResult = data.SingleResult;
                    result.Code = Common.CodeType.Ok;
                }
                else
                {
                    result.Code = Common.CodeType.Error;
                    result.Message = data.result.ErrorDescription;
                }
            }
            catch (Exception ex)
            {
                result.Code = Common.CodeType.Error;
                result.Message = ex.Message;
            }
            return
                result;

        }


        #region Private Methods

        private void SetNameIDSysflex(AgentResult agentData)
        {
            string newNameID = "";
            string agentCode = "";
            string Name = "";
            string LastName = "";

            var ag = agentData.ExecutionResult;

            if (ag != null && ag.NameId.notNullOrEmptyOrWitheSpaces() == false)
            {
                agentCode = ag.AgentCode;

                var strName = ag.FirstName;

                var nameChar = strName.Select(c =>
                {
                    if (!char.IsLetter(c)) return ',';
                    return c;
                }).ToArray();

                var outputN = new string(nameChar);
                Name = outputN.Replace(",", "").Replace(" ", "").Replace("ñ", "n").Replace("Ñ", "N").ToUpper();

                var strLastName = ag.FirstLastname;

                var lastnameChar = strLastName.Select(c =>
                {
                    if (!char.IsLetter(c)) return ',';
                    return c;
                }).ToArray();

                var outputL = new string(lastnameChar);
                LastName = outputL.Replace(",", "").Replace(" ", "").Replace("ñ", "n").Replace("Ñ", "N").ToUpper();

                if (agentCode.notNullOrEmptyOrWitheSpaces() && Name.notNullOrEmptyOrWitheSpaces() && LastName.notNullOrEmptyOrWitheSpaces())
                {
                    newNameID = agentCode + "" + Name.Substring(0, 2) + LastName.Substring(0, 2);

                    bool exist = checkNameIDExiste(ag.AgentId.GetValueOrDefault(), newNameID);
                    int index = 1;

                    while (exist == true)
                    {
                        if (index >= 60 || index >= Name.Length || index >= LastName.Length)
                        {
                            exist = false;
                        }

                        newNameID = agentCode + "" + Name.Substring(0, index) + LastName.Substring(0, index);
                        exist = checkNameIDExiste(ag.AgentId.GetValueOrDefault(), newNameID);

                        index++;
                    }
                }
                else if (LastName.notNullOrEmptyOrWitheSpaces() == false)
                {
                    newNameID = agentCode + "" + Name.Substring(0, 4);

                    bool exist = checkNameIDExiste(ag.AgentId.GetValueOrDefault(), newNameID);
                    int index = 3;

                    while (exist == true)
                    {
                        if (index >= 60 || index >= Name.Length)
                        {
                            exist = false;
                        }

                        newNameID = agentCode + "" + Name.ToUpper().Substring(0, index);
                        exist = checkNameIDExiste(ag.AgentId.GetValueOrDefault(), newNameID);

                        index++;
                    }
                }
                //ag.NameId = newNameID.Trim();

                if (!string.IsNullOrEmpty(newNameID))
                {
                    #region Actualizando el Name_Id del agente

                    SetAgent(new AgentInformation()
                    {
                        AgentId = ag.AgentId,
                        NameId = newNameID.Trim(),
                        //Esto hay que hacerlo en el update porque sino da error
                        Gender = Gender.NA,
                        IdentityTypeId = IdentityType.NA
                        //Esto hay que hacerlo en el update porque sino da error
                    });

                    #endregion
                }
            }
        }

        private void SetNameIDLife(int agentId, string nameId, string sourceId)
        {
            if (!string.IsNullOrEmpty(nameId))
            {
                #region Actualizando el Name_Id del agente

                SetAgent(new AgentInformation()
                {
                    AgentId = agentId,
                    NameId = nameId,
                    SourceId = sourceId,

                    //Esto hay que hacerlo en el update porque sino da error
                    Gender = Gender.NA,
                    IdentityTypeId = IdentityType.NA
                    //Esto hay que hacerlo en el update porque sino da error
                });

                #endregion
            }
        }

        private bool checkNameIDExiste(int agentId, string NameID)
        {
            var ag = oAgentManager.GetAgentByNameId(NameID);
            if (ag.SingleResult != null && ag.SingleResult.AgentId != agentId)
            {
                return true;
            }

            return false;
        }

        private string getSourceIDByAgent(int agentId)
        {
            var ag = oAgentManager.GetAgent(agentId);
            if (ag.SingleResult != null)
            {
                return ag.SingleResult.SourceId;
            }

            return "";
        }

        private string getNameidByAgent(int agentId)
        {
            var ag = oAgentManager.GetAgent(agentId);
            if (ag.SingleResult != null)
            {
                return ag.SingleResult.NameId;
            }

            return "";
        }

        public void UpdateSourceIDAgentHealth(int agentId)
        {
            var adata = oAgentManager.GetAgent(agentId);
            if (adata.SingleResult != null)
            {
                string currSourceId = adata.SingleResult.SourceId;
                string newSourceID = currSourceId.Replace("ATL-VEH-", "ATL-HEA-");

                if (!string.IsNullOrEmpty(newSourceID))
                {
                    #region Actualizando el Source_Id del agente

                    SetAgent(new AgentInformation()
                    {
                        AgentId = adata.SingleResult.AgentId,
                        SourceId = newSourceID.Trim(),

                        //Esto hay que hacerlo en el update porque sino da error
                        Gender = Gender.NA,
                        IdentityTypeId = IdentityType.NA
                        //Esto hay que hacerlo en el update porque sino da error
                    });

                    #endregion
                }
            }
        }
        #endregion
    }
}
