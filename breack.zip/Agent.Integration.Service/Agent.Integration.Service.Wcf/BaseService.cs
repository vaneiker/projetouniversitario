﻿using Agent.Integration.Service.Logic.Manager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Agent.Integration.Service.Wcf
{
    public class BaseService
    {
        public BaseService() { }

        public DocumentManager oDocumentManager
        {
            get
            {
                return
                    new DocumentManager();
            }
        }

        public AgentManager oAgentManager
        {
            get
            {
                return
                    new AgentManager();
            }
        }

        public AgentToSysFlex.AgentServiceClient oAgentService
        {
            get
            {
                return
                    new AgentToSysFlex.AgentServiceClient();
            }
        }

        public AgentToAdvisor.AgentClient oAgentServiceAdvisor
        {
            get
            {
                return
                    new AgentToAdvisor.AgentClient();
            }
        }
    }
}