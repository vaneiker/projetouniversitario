﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Agent.Integration.Service.Wcf.DataContracts
{
    #region Enums

    public enum IdentityType
    {
        NA=0,
        PersonaJuridica = 10,
        PersonaFisica = 11
    }

    public enum Gender
    {
        NA=0,
        Female,
        Male,
        Company
    }

    public enum CommunicationTypes
    {
        Address = 4,
        Phone = 1,
        Email = 2
    }

    public enum PhoneTypes
    {
        NA = 0,
        Home = 14,
        Work = 15,
        CellPhone = 22
    }

    public enum DirectoryTypes
    {
        NA = 0,
        PersonalEmail = 2,
        WorkEmail = 9,
        HomePhone = 6,
        WorkPhone = 7,
        CellPhone = 8
    }

    public enum SuperintendenceLicencesID
    {
        NA = 0,
        Corridors = 236,
        Intermediaries = 270,
        DriverLicence = 198
    }

    public enum SuperintendenceLicencesDocumentId
    {
        NA = 1,
        DriverLicence = 1,
        Corridors = 15814,
        Intermediaries = 110
    }

    public enum ChainCodes
    {
        Life = 133,
        Auto = 130,
        Health = 218
    }

    public enum BussinessLines
    {
        Life = 1,
        Auto = 2,
        Health = 3
    }

    #endregion

    public class AgentInformation
    {
        public int? AgentId { get; set; }
        public IdentityType IdentityTypeId { get; set; }
        public string IdentificationNumber { get; set; }
        public string AgentCode { get; set; }
        public string NameId { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string FirstLastName { get; set; }
        public string SecondLastname { get; set; }
        public string NickName { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public int? PaymentTypeId { get; set; }
        public string ABANumber { get; set; }
        public string BankAccountNumber { get; set; }
        public int? AllocationTypeId { get; set; }
        public Gender Gender { get; set; }
        public int? ResidenceCountryId { get; set; }
        public int? BirthCountryId { get; set; }
        public int? CityId { get; set; }
        public int? DirectoryId { get; set; }
        public DateTime? ActiveDate { get; set; }
        public DateTime? InactiveDate { get; set; }
        public DateTime? IdExpirationDate { get; set; }
        public int? CommissionBehaviorId { get; set; }
        public int? ExpedientId { get; set; }
        public string ReferencedBy { get; set; }
        public string ContactNotes { get; set; }
        public string HistoryNotes { get; set; }
        public int? AutomaticCancellationDays { get; set; }
        public int? UserId { get; set; }
        public int? UbicationSysflex { get; set; }
        public string SourceId { get; set; }

        public class ComunicationData
        {
            public Nullable<int> DirectoryId { get; set; }
            public Nullable<int> DirDetailId { get; set; }
            public CommunicationTypes CommTypeId { get; set; }
            public DirectoryTypes DirectoryTypeId { get; set; }
            public PhoneTypes PhoneTypeId { get; set; }
            public string PhoneNumber { get; set; }
            public string Address { get; set; }
            public Nullable<int> CountryId { get; set; }
            public Nullable<int> CityId { get; set; }
            public Nullable<bool> IsPrimary { get; set; }
            public int UsrId { get; set; }
        }

        public class LicenseData
        {
            public Nullable<int> AgentId { get; set; }
            public string Id { get; set; }
            public Nullable<System.DateTime> ValidDate { get; set; }
            public Nullable<System.DateTime> ExpireDate { get; set; }
            public Nullable<System.DateTime> RevalidationDate { get; set; }
            public Nullable<int> CountryId { get; set; }
            public SuperintendenceLicencesID DocCategoryId { get; set; }
            public int? UserId { get; set; }
        }

        public class OfficeData
        {
            public Nullable<int> OfficeId { get; set; }
            public Nullable<int> AgentId { get; set; }
            public Nullable<System.DateTime> AssignedDate { get; set; }
            public Nullable<System.DateTime> UnassignDate { get; set; }
            public int UsrId { get; set; }
        }

        public class BusinessLine
        {
            public Nullable<int> OfficeId { get; set; }
            public Nullable<int> AgentId { get; set; }
            public int UsrId { get; set; }
        }

        public class ChainDetail
        {
            public ChainCodes ChainId { get; set; }
            public Nullable<int> ChainDetId { get; set; }
            public Nullable<int> AgentId { get; set; }
            public Nullable<bool> AgentChainStatus { get; set; }
            public Nullable<int> SupervisorAgentId { get; set; }
            public Nullable<System.DateTime> DateAssigned { get; set; }
            public Nullable<System.DateTime> DateUnassigned { get; set; }
            public Nullable<int> UserId { get; set; }
            public BussinessLines BussinessLine { get; set; }
            public Nullable<int> DistributionId { get; set; }
        }

        public class SalesChannel
        {
            public int? AgentId { get; set; }
            public int? DistributionId { get; set; }
            public int? UserId { get; set; }
        }

        public class AgentDocument
        {
            public int AgentId { get; set; }
            public int DocTypeId { get; set; }
            public int DocCategoryId { get; set; }
            public int DocumentId { get; set; }
            public int UserId { get; set; }
        }

        public class AgentChanger
        {
            public DateTime DateOut { get; set; }
            public DateTime DateIn { get; set; }
            public string Note { get; set; }
            public string User { get; set; }
            public int? NewSupervisAgentId { get; set; }
            public int? NewSupervisAgentCode { get; set; }
            public string AgentIds { get; set; }
            public string AgentCodes { get; set; }
            public int ModiUser { get; set; }
        }
    }
}