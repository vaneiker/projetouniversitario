﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace Agent.Integration.Service.Wcf.DataContracts
{
    [DataContract]  
    public class Document
    {
        [DataMember]
        public Nullable<int> DocTypeId { get; set; }
        [DataMember]
        public Nullable<int> DocCategoryId { get; set; }
        [DataMember]
        public int DocumentId { get; set; }
        [DataMember]
        public byte[] DocumentBinary { get; set; }
        [DataMember]
        public string DocumentName { get; set; }
        /*[DataMember]
        public DateTime? FileCreationDate { get; set; }
        [DataMember]
        public DateTime? FileExpireDate { get; set; }
        */
        [DataMember]
        public int? userId { get; set; }
    }


    public class ExportedFiles
    {
        public Nullable<int> ExportedFilesId { get; set; }
        public Nullable<int> AgentId { get; set; }
        public Nullable<int> DocTypeId { get; set; }
        public Nullable<int> DocCategoryId { get; set; }
        public Nullable<int> DocumentId { get; set; }
        public string DocumentName { get; set; }
        public DateTime? ExportedDate { get; set; }
        public int? UserId { get; set; }
    }
}