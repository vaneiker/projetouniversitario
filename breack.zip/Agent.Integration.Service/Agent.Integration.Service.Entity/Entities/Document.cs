﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agent.Integration.Service.Entity.Entities
{
    public class Document
    {
        public Nullable<int> DocTypeId { get; set; }
        public Nullable<int> DocCategoryId { get; set; }
        public object DocumentId { get; set; }
        public byte[] DocumentBinary { get; set; }
        public string DocumentName { get; set; }
        public Nullable<System.DateTime> FileCreationDate { get; set; }
        public Nullable<System.DateTime> FileExpireDate { get; set; }
        public int userId { get; set; }

        public class ExportedFiles
        {
            public Nullable<int> ExportedFilesId { get; set; }
            public Nullable<int> AgentId { get; set; }
            public Nullable<int> DocTypeId { get; set; }
            public Nullable<int> DocCategoryId { get; set; }
            public Nullable<int> DocumentId { get; set; }
            public string DocumentName { get; set; }
            public Nullable<System.DateTime> ExportedDate { get; set; }
            public int UserId { get; set; }
        }
    }
}
