﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agent.Integration.Service.Entity.Entities
{
    public class AgentIntegration
    {
        public class Agent
        {
            public Nullable<int> AgentId { get; set; }
            public Nullable<int> IdentityTypeId { get; set; }
            public string IdentificationNumber { get; set; }
            public string AgentCode { get; set; }
            public string NameId { get; set; }
            public string FirstName { get; set; }
            public string MiddleName { get; set; }
            public string FirstLastName { get; set; }
            public string SecondLastname { get; set; }
            public string NickName { get; set; }
            public Nullable<System.DateTime> DateOfBirth { get; set; }
            public Nullable<int> PaymentTypeId { get; set; }
            public string ABANumber { get; set; }
            public string BankAccountNumber { get; set; }
            public Nullable<int> AllocationTypeId { get; set; }
            public string Gender { get; set; }
            public Nullable<int> ResidenceCountryId { get; set; }
            public Nullable<int> BirthCountryId { get; set; }
            public Nullable<int> CitizenshipCountryId { get; set; }
            public Nullable<int> DirectoryId { get; set; }
            public Nullable<System.DateTime> ActiveDate { get; set; }
            public Nullable<System.DateTime> InactiveDate { get; set; }
            public Nullable<System.DateTime> IdExpirationDate { get; set; }
            public Nullable<int> CommissionBehaviorId { get; set; }
            public Nullable<int> ExpedientId { get; set; }
            public string ReferencedBy { get; set; }
            public string ContactNotes { get; set; }
            public string HistoryNotes { get; set; }
            public Nullable<int> AutomaticCancellationDays { get; set; }
            public int UserId { get; set; }
            public int? UbicationSysflex { get; set; }
            public string SourceId { get; set; }
        }



        public class Communication
        {
            public class ComunicationData
            {
                public Nullable<int> CorpId { get; set; }
                public Nullable<int> DirectoryId { get; set; }
                public Nullable<int> DirDetailId { get; set; }
                public Nullable<int> CommTypeId { get; set; }
                public Nullable<int> DirectoryTypeId { get; set; }
                public Nullable<int> PhoneTypeId { get; set; }
                public string PhonePrefix { get; set; }
                public string AreaCode { get; set; }
                public string PhoneNumber { get; set; }
                public string PhoneExt { get; set; }
                public string Address { get; set; }
                public string PersonToContact { get; set; }
                public Nullable<int> RegionId { get; set; }
                public Nullable<int> CountryId { get; set; }
                public Nullable<int> DomesticRegionId { get; set; }
                public Nullable<int> StateProvId { get; set; }
                public Nullable<int> CityId { get; set; }
                public Nullable<int> AreaId { get; set; }
                public string AddressNo { get; set; }
                public string BlgdNumber { get; set; }
                public string Floor { get; set; }
                public string Door { get; set; }
                public string NearToReference { get; set; }
                public string ZipCode { get; set; }
                public Nullable<bool> IsPrimary { get; set; }
                public string Comments { get; set; }
                public int UsrId { get; set; }
            }

        }

        public class License
        {
            public class LicenseData
            {
                public Nullable<int> CorpId { get; set; }
                public Nullable<int> AgentId { get; set; }
                public Nullable<int> SeqNo { get; set; }
                public Nullable<int> AgentIdType { get; set; }
                public string Id { get; set; }
                public Nullable<System.DateTime> ValidDate { get; set; }
                public Nullable<System.DateTime> ExpireDate { get; set; }
                public Nullable<System.DateTime> RevalidationDate { get; set; }
                public Nullable<int> CountryId { get; set; }
                public Nullable<int> DocTypeId { get; set; }
                public Nullable<int> DocCategoryId { get; set; }
                public Nullable<int> DocumentId { get; set; }
                public Nullable<bool> StatusId { get; set; }
                public int? UserId { get; set; }
            }
        }

        public class AssignedOffice
        {
            public class OfficeData
            {
                public Nullable<int> CorpId { get; set; }
                public Nullable<int> RegionId { get; set; }
                public Nullable<int> CountryId { get; set; }
                public Nullable<int> DomesticRegId { get; set; }
                public Nullable<int> StateProvId { get; set; }
                public Nullable<int> CityId { get; set; }
                public Nullable<int> OfficeId { get; set; }
                public Nullable<int> AgentTypeId { get; set; }
                public Nullable<int> AgentId { get; set; }
                public Nullable<System.DateTime> AssignedDate { get; set; }
                public Nullable<System.DateTime> UnassignDate { get; set; }
                public int UsrId { get; set; }
            }
        }

        public class BusinessLine
        {
            public class Data
            {
                public Nullable<int> CorpId { get; set; }
                public Nullable<int> RegionId { get; set; }
                public Nullable<int> CountryId { get; set; }
                public Nullable<int> DomesticRegId { get; set; }
                public Nullable<int> StateProvId { get; set; }
                public Nullable<int> CityId { get; set; }
                public Nullable<int> OfficeId { get; set; }
                public Nullable<int> BlTypeID { get; set; }
                public Nullable<int> BlId { get; set; }
                public Nullable<int> ProductId { get; set; }
                public Nullable<int> AgentId { get; set; }
                public Nullable<int> AgentTypeId { get; set; }
                public Nullable<System.DateTime> AssignedDate { get; set; }
                public Nullable<System.DateTime> UnassignDate { get; set; }
                public Nullable<System.DateTime> ActivationDate { get; set; }
                public Nullable<System.DateTime> InactivationDate { get; set; }
                public int UsrId { get; set; }
            }
        }

        public class ChainDetail
        {
            public Nullable<int> CorpId { get; set; }
            public Nullable<int> ChainId { get; set; }
            public Nullable<int> ChainDetId { get; set; }
            public Nullable<int> AgentId { get; set; }
            public Nullable<int> OrderId { get; set; }
            public Nullable<int> ChainLevelId { get; set; }
            public Nullable<bool> AgentChainStatus { get; set; }
            public Nullable<int> SupervisorAgentId { get; set; }
            public Nullable<int> RelationshipToSupervisor { get; set; }
            public Nullable<System.DateTime> DateAssigned { get; set; }
            public Nullable<System.DateTime> DateUnassigned { get; set; }
            public string SourceID { get; set; }
            public Nullable<int> UserId { get; set; }

        }

        public class SalesChannel
        {
            public int CorpId { get; set; }
            public int AgentId { get; set; }
            public int DistributiomId { get; set; }
            public bool ChannelDistribStatusId { get; set; }
            public int UserId { get; set; }

        }

        public class AgentDocument
        {
            public int CorpId { get; set; }
            public int AgentId { get; set; }
            public int DocTypeId { get; set; }
            public int DocCategoryId { get; set; }
            public int DocumentId { get; set; }
            public bool AgentDocumentStatus { get; set; }
            public int UserId { get; set; }
        }

        public class AgentChange
        {
            public DateTime DateOut { get; set; }
            public DateTime DateIn { get; set; }
            public string Note { get; set; }
            public string User { get; set; }
            public int? NewSupervisAgentId { get; set; }
            public int? NewSupervisAgentCode { get; set; }
            public string AgentIds { get; set; }
            public string AgentCodes { get; set; }
            public int ModiUser { get; set; }

        }
    }
}
