﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agent.Integration.Service.Logic
{
    public class ResultLogic<T> : BaseResultLogic<T> where T : class
    {
        /// <summary>
        /// En esta propiedad se devuelve el objeto exeption
        /// </summary>
        public Exception _exception { get; set; }

        /// <summary>
        /// En esta propiedad se devuelve un ienumerable del Tipo T
        /// </summary>
        public IEnumerable<T> dataResult { get; set; }
        /// <summary>
        /// En esta propiedad se devuelve un tipo T
        /// </summary>
        public T SingleResult { get; set; }

        /// <summary>
        /// En esta propiedad se devolveria un valor de tipo primitivo Ej: bool int, decimal, string etc
        /// </summary>
        public PrimitiveResult primitiveResult { get; set; }
    }

    public class PrimitiveResult
    {
        public object Result { get; set; }
    }
}
