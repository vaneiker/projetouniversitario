﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agent.Integration.Service.Logic
{
    /// <summary>
    /// This class represent the result of the operation executed
    /// </summary>
    public class Result
    {
        public bool HasError { get; set; }
        public string ErrorDescription { get; set; }
        public string ExceptionMessage { get; set; }
        public string InnerException { get; set; }
        public string TraceStack { get; set; }
        public string MethodName { get; set; }
        public string Action { get; set; }
        public long? entityId { get; set; }
        public Result(Exception e = null, string methodName = null)
        {
            this.ErrorDescription = (e != null) ? string.Format("Method {0} ExceptionMessage {1} InnerException {2} TraceStack {3}", methodName, e.Message, e.InnerException != null ? e.InnerException.Message : "", e.StackTrace)
                                                : string.Empty;

            this.ExceptionMessage = (e != null) ? e.Message : "";
            this.InnerException = (e != null) ? e.InnerException != null ? e.InnerException.Message : "" : "";
            this.TraceStack = (e != null) ? e.StackTrace : "";
            this.MethodName = methodName;
            this.HasError = e != null;
        }
    }
}
