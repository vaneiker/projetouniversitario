﻿using Agent.Integration.Service.Data;
using Agent.Integration.Service.Data.Repositories;
using Agent.Integration.Service.Entity.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agent.Integration.Service.Logic.Manager
{
    public class DocumentManager: BaseManager<DocumentRepository>
    {
        public DocumentManager() {_Repository = SingletonRepository.Instance.DocumentRepository;    }

        public ResultLogic<RepositoryResult> SetDocument(Document document)
        {
            ResultLogic<RepositoryResult> _Result;
            try
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    SingleResult = _Repository.SetDocument(document),
                    result = new Result(null, null)
                };
            }
            catch (Exception ex)
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    result = new Result(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
                };
            }
            return
                _Result;
        }

        public ResultLogic<RepositoryResult> SetExportedFile(Document.ExportedFiles file)
        {
            ResultLogic<RepositoryResult> _Result;
            try
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    SingleResult = _Repository.SetExportedFile(file),
                    result = new Result(null, null)
                };
            }
            catch (Exception ex)
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    result = new Result(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
                };
            }
            return
                _Result;
        }

        public ResultLogic<RepositoryResult> GetDocumentForAgents()
        {
            ResultLogic<RepositoryResult> _Result;
            try
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    dataResult = _Repository.GetDocumentForAgents(),
                    result = new Result(null, null)
                };
            }
            catch (Exception ex)
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    result = new Result(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
                };
            }
            return
                _Result;
        }
    }
}
