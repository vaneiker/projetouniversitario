﻿using Agent.Integration.Service.Data;
using Agent.Integration.Service.Data.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agent.Integration.Service.Logic.Manager
{
    public class BaseManager<T>
    {
        protected Result Result;
        private string MessageErrorFormat;
        private BaseRepository _baseRepository;
        protected T _Repository;

        public BaseManager(Result result = null)
        {
            this._baseRepository = SingletonRepository.Instance.BaseRepository;
            this.Result = (result == null) ? new Result { HasError = false, ErrorDescription = string.Empty } : result;
        }
    }
}
