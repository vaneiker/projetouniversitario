﻿using Agent.Integration.Service.Data;
using Agent.Integration.Service.Data.Repositories;
using Agent.Integration.Service.Entity.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace Agent.Integration.Service.Logic.Manager
{
    public class AgentManager : BaseManager<AgentRepository>
    {
        public AgentManager() { _Repository = SingletonRepository.Instance.AgentRepository; }

        public class Agentes
        {
            public int? AgentId { get; set; }
            public int? Offices { get; set; }
        }

        public class Oficina
        {
            public int? agentSupervisor { get; set; }
            public int? Corp_Id { get; set; }
            public int? Region_Id { get; set; }
            public int? Country_Id { get; set; }
            public int? DomesticReg_Id { get; set; }
            public int? State_Prov_Id { get; set; }
            public int? City_Id { get; set; }
            public int? Office_Id { get; set; }
            public int? Agent_Type_Id { get; set; }
            public int? Agent_Id { get; set; }
            public bool? Agent_Assinged_Status { get; set; }
        }

        public ResultLogic<RepositoryResult> SetAgent(AgentIntegration.Agent AgentData)
        {
            ResultLogic<RepositoryResult> _Result;

            try
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    SingleResult = _Repository.SetAgent(AgentData),
                    result = new Result(null, null)
                };
            }
            catch (Exception ex)
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    result = new Result(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
                };
            }

            return
                _Result;
        }

        public ResultLogic<RepositoryResult> SetAgentCommunication(AgentIntegration.Communication.ComunicationData CommunicationData)
        {
            ResultLogic<RepositoryResult> _Result;

            try
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    SingleResult = _Repository.SetAgentCommunication(CommunicationData),
                    result = new Result(null, null)
                };
            }
            catch (Exception ex)
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    result = new Result(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
                };
            }

            return
                _Result;
        }

        public ResultLogic<PrimitiveResult> SetAgentIndex(int? CorpId, int? AgentId, decimal? IndexValue, int UserId)
        {
            ResultLogic<PrimitiveResult> _Result;
            try
            {
                _Result = new ResultLogic<PrimitiveResult>
                {
                    primitiveResult = new PrimitiveResult { Result = _Repository.SetAgentIndex(CorpId, AgentId, IndexValue, UserId) },
                    result = new Result(null, null)
                };
            }
            catch (Exception ex)
            {
                _Result = new ResultLogic<PrimitiveResult>
                {
                    result = new Result(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
                };
            }

            return
                _Result;
        }

        public ResultLogic<PrimitiveResult> SetPropertyAgentIndex(int? CorpId, int? AgentId, decimal? IndexValue, int UserId)
        {
            ResultLogic<PrimitiveResult> _Result;
            try
            {
                _Result = new ResultLogic<PrimitiveResult>
                {
                    primitiveResult = new PrimitiveResult { Result = _Repository.SetPropertyAgentIndex(CorpId, AgentId, IndexValue, UserId) },
                    result = new Result(null, null)
                };
            }
            catch (Exception ex)
            {
                _Result = new ResultLogic<PrimitiveResult>
                {
                    result = new Result(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
                };
            }

            return
                _Result;
        }

        public ResultLogic<RepositoryResult> SetAgentUniqueMatch(Nullable<int> CorpId, Nullable<int> AgentId, Nullable<int> UniqueAgentId, string LastNumberId, Nullable<System.DateTime> DateOfBirth, int UserId)
        {
            ResultLogic<RepositoryResult> _Result;

            try
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    SingleResult = _Repository.SetAgentUniqueMatch(CorpId, AgentId, UniqueAgentId, LastNumberId, DateOfBirth, UserId),
                    result = new Result(null, null)
                };
            }
            catch (Exception ex)
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    result = new Result(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
                };
            }

            return
                _Result;
        }

        public ResultLogic<RepositoryResult> SetAgentLicense(AgentIntegration.License.LicenseData LicenseData)
        {
            ResultLogic<RepositoryResult> _Result;
            try
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    SingleResult = _Repository.SetAgentLicense(LicenseData),
                    result = new Result(null, null)
                };
            }
            catch (Exception ex)
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    result = new Result(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
                };
            }
            return
                _Result;
        }

        public ResultLogic<RepositoryResult> SetAssignedAgentOffice(AgentIntegration.AssignedOffice.OfficeData OfficeData)
        {
            ResultLogic<RepositoryResult> _Result;
            try
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    SingleResult = _Repository.SetAssignedAgentOffice(OfficeData),
                    result = new Result(null, null)
                };
            }
            catch (Exception ex)
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    result = new Result(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
                };
            }
            return
                _Result;
        }

        public ResultLogic<RepositoryResult> SetAgentBusinessLine(AgentIntegration.BusinessLine.Data BusinessLine)
        {
            ResultLogic<RepositoryResult> _Result;
            try
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    SingleResult = _Repository.SetAgentBusinessLine(BusinessLine),
                    result = new Result(null, null)
                };
            }
            catch (Exception ex)
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    result = new Result(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
                };
            }
            return
                _Result;
        }

        public ResultLogic<RepositoryResult> SetAgentChainDetail(AgentIntegration.ChainDetail ChainDetail)
        {
            ResultLogic<RepositoryResult> _Result;
            try
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    SingleResult = _Repository.SetAgentChainDetail(ChainDetail),
                    result = new Result(null, null)
                };
            }
            catch (Exception ex)
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    result = new Result(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
                };
            }
            return
                _Result;
        }

        public ResultLogic<RepositoryResult> SetAgentSalesChannel(AgentIntegration.SalesChannel SalesChannel)
        {
            ResultLogic<RepositoryResult> _Result;
            try
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    SingleResult = _Repository.SetAgentSalesChannel(SalesChannel),
                    result = new Result(null, null)
                };
            }
            catch (Exception ex)
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    result = new Result(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
                };
            }
            return
                _Result;
        }

        public ResultLogic<RepositoryResult> SetAgentDocument(AgentIntegration.AgentDocument AgentDocument)
        {
            ResultLogic<RepositoryResult> _Result;
            try
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    SingleResult = _Repository.SetAgentDocument(AgentDocument),
                    result = new Result(null, null)
                };
            }
            catch (Exception ex)
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    result = new Result(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
                };
            }
            return
                _Result;
        }

        public ResultLogic<RepositoryResult> GetAgentSalesChannelLevel(int distributionId, int Bl_Id)
        {
            ResultLogic<RepositoryResult> _Result;
            try
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    SingleResult = _Repository.GetAgentSalesChannelLevel(distributionId, Bl_Id),
                    result = new Result(null, null)
                };
            }
            catch (Exception ex)
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    result = new Result(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
                };
            }
            return
                _Result;
        }

        public ResultLogic<RepositoryResult> GetOfficeBLById(int officeId)
        {
            ResultLogic<RepositoryResult> _Result;
            try
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    dataResult = _Repository.GetOfficeBLById(officeId),
                    result = new Result(null, null)
                };
            }
            catch (Exception ex)
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    result = new Result(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
                };
            }
            return
                _Result;
        }

        public ResultLogic<RepositoryResult> GetOfficeById(int officeId)
        {
            ResultLogic<RepositoryResult> _Result;
            try
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    SingleResult = _Repository.GetOfficeById(officeId),
                    result = new Result(null, null)
                };
            }
            catch (Exception ex)
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    result = new Result(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
                };
            }
            return
                _Result;
        }

        public ResultLogic<PrimitiveResult> GetNextDirectoryId()
        {
            ResultLogic<PrimitiveResult> _Result;
            try
            {
                _Result = new ResultLogic<PrimitiveResult>
                {
                    primitiveResult = new PrimitiveResult { Result = _Repository.GetNextDirectoryId() },
                    result = new Result(null, null)
                };
            }
            catch (Exception ex)
            {
                _Result = new ResultLogic<PrimitiveResult>
                {
                    result = new Result(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
                };
            }

            return
                _Result;
        }

        public ResultLogic<RepositoryResult> GetAgentBussinessLine(int agentId)
        {
            ResultLogic<RepositoryResult> _Result;
            try
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    SingleResult = _Repository.GetAgentBussinessLine(agentId),
                    result = new Result(null, null)
                };
            }
            catch (Exception ex)
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    result = new Result(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
                };
            }

            return
                _Result;
        }

        public ResultLogic<RepositoryResult> GetSysflexProvince(int? provinceId)
        {
            ResultLogic<RepositoryResult> _Result;
            try
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    dataResult = _Repository.GetSysflexProvince(provinceId),
                    result = new Result(null, null)
                };
            }
            catch (Exception ex)
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    result = new Result(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
                };
            }
            return
                _Result;
        }

        public ResultLogic<RepositoryResult> GetSysflexMunicipalities(int provinceId, int? municipe)
        {
            ResultLogic<RepositoryResult> _Result;
            try
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    dataResult = _Repository.GetSysflexMunicipalities(provinceId, municipe),
                    result = new Result(null, null)
                };
            }
            catch (Exception ex)
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    result = new Result(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
                };
            }
            return
                _Result;
        }

        public ResultLogic<RepositoryResult> GetSysflexCity(int provinceId, int municipe, int? cityId)
        {
            ResultLogic<RepositoryResult> _Result;
            try
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    dataResult = _Repository.GetSysflexCity(provinceId, municipe, cityId),
                    result = new Result(null, null)
                };
            }
            catch (Exception ex)
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    result = new Result(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
                };
            }
            return
                _Result;
        }

        public ResultLogic<RepositoryResult> GetAgent(int agentId)
        {
            ResultLogic<RepositoryResult> _Result;

            try
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    SingleResult = _Repository.GetAgent(agentId),
                    result = new Result(null, null)
                };
            }
            catch (Exception ex)
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    result = new Result(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
                };
            }

            return
                _Result;
        }

        public ResultLogic<RepositoryResult> GetAgentByNameId(string nameId)
        {
            ResultLogic<RepositoryResult> _Result;

            try
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    SingleResult = _Repository.GetAgentByNameId(nameId),
                    result = new Result(null, null)
                };
            }
            catch (Exception ex)
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    result = new Result(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
                };
            }

            return
                _Result;
        }



        public ResultLogic<RepositoryResult> SetAgentChangeIntermediaryPortfolio(AgentIntegration.AgentChange parameters)
        {

            ResultLogic<RepositoryResult> _Result;
            try
            {
                //Obtengo el codigo del supervisor
                var supervisor = _Repository.GetSerachSuperVisor(parameters.NewSupervisAgentId);

                string[] AgentId = parameters.AgentIds.Split(',');
                foreach (string agentid in AgentId)
                {
                    var agente = _Repository.GetSerachAgent(int.Parse(agentid.ToString()), supervisor.OfficeId);

                    if (supervisor.OfficeId != agente.OfficeId)
                    {

                        //Quitar la officina al agente 
                        _Repository.UpdateOfficeAgent(int.Parse(agentid.ToString()), agente.OfficeId);
                        //agregale la oficina del agente

                        _Repository.InsertOfficeAgent(supervisor.CorpId,
                                                      supervisor.RegionId,
                                                      supervisor.CountryId,
                                                      supervisor.DomesticRegId,
                                                      supervisor.StateProvId,
                                                      supervisor.CityId,
                                                      supervisor.OfficeId,
                                                      int.Parse(agentid.ToString()));
                    }
                    else
                    {
                        _Repository.UpdateOfficesNetx(agente.OfficeId, int.Parse(agentid.ToString()), parameters.ModiUser);
                    }
                }

                _Result = new ResultLogic<RepositoryResult>
                {
                    SingleResult = _Repository.GetAgentChangeIntermediaryPortfolio(parameters),
                    result = new Result(null, null)
                };
            }
            catch (Exception ex)
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    result = new Result(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
                };
            }

            return
                _Result;
        }

        public ResultLogic<RepositoryResult> SetCreateUsersSecurityAgent(string Agent_Code, int UserId, string email, int createUsers, string UserLogin = "")
        {
            ResultLogic<RepositoryResult> _Result;
            try
            {

                if (UserId > 0)
                {
                    var existUser = _Repository.EXISTS_USER(UserLogin);

                    if (existUser.UserLogin != "NOT-USERLOGIN")
                    {
                        UserLogin = UserLogin + "A";
                    }

                    _Result = new ResultLogic<RepositoryResult>
                    {
                        SingleResult = _Repository.UpdateUser(Agent_Code, UserId, createUsers, email, UserLogin),
                        result = new Result(null, null)
                    };
                }
                else
                {
                    _Result = new ResultLogic<RepositoryResult>
                    {
                        SingleResult = _Repository.SetCreateUsersSecurityAgent(Agent_Code, UserId, email),
                        result = new Result(null, null)
                    };
                }
            }
            catch (Exception ex)
            {
                _Result = new ResultLogic<RepositoryResult>
                {
                    result = new Result(ex, System.Reflection.MethodBase.GetCurrentMethod().Name)
                };
            }

            return
                _Result;
        }
    }
}
