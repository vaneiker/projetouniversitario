﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agent.Integration.Service.Logic
{
    public class BaseResultLogic<T> where T : class
    {
        public T entity { get; set; }
        public Result result { get; set; }
    }
}
