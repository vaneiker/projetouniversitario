﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agent.Integration.Service.Test
{
    class Program
    {
        static void Main(string[] args)
        {
            AgentIntegrationService.AgentIntegrationServiceClient aservice = new AgentIntegrationService.AgentIntegrationServiceClient();

            int userid = 414;
            int? agentIdNew = null;//El que se creo nuevo
            int? newDirectoryId = null;
            string identificationNumber = "000-0000000-0";
            DateTime? dob = new DateTime(1989, 12, 09);

            try
            {

                var xxxxx = aservice.GetAgent(35099);


            }
            catch (Exception)
            {

                throw;
            }


            var IdentityTypeId = AgentIntegrationService.IdentityType.PersonaFisica;
            var gender = AgentIntegrationService.Gender.Male;

            var agentResult = aservice.SetAgent(new AgentIntegrationService.AgentInformation()
            {
                AgentId = agentIdNew,
                IdentityTypeId = IdentityTypeId,
                IdentificationNumber = identificationNumber,
                Gender = gender,
                DateOfBirth = dob,
                FirstName = "Jheiron",
                FirstLastName = "Dotel 01",
                BirthCountryId = 129,
                CityId = 817,
                ResidenceCountryId = 129,
                ActiveDate = DateTime.Now,
                ExpedientId = 1,
                DirectoryId = -1,
                UserId = userid
            });


            if (agentResult.Code == AgentIntegrationService.CodeType.Ok)
            {
                agentIdNew = agentResult.ExecutionResult.AgentId;
                int officeId = 1;//Plaza Uris


                #region Creacion de Direccon,Telefono y demas

                var commTypeId = AgentIntegrationService.CommunicationTypes.Address;
                var directoryTypeId = AgentIntegrationService.DirectoryTypes.NA;

                #region Registrando la direccion

                var agentCommunication = aservice.SetAgentCommunication(new AgentIntegrationService.AgentInformation.ComunicationData()
                {
                    DirDetailId = null,
                    DirectoryId = newDirectoryId,
                    CommTypeId = commTypeId,
                    Address = "Mi direccion",
                    CountryId = 129,
                    CityId = 817,
                    DirectoryTypeId = directoryTypeId,
                    IsPrimary = true,
                    UsrId = userid,
                    PhoneTypeId = AgentIntegrationService.PhoneTypes.NA
                });

                #endregion

                if (agentCommunication.Code == AgentIntegrationService.CodeType.Ok)
                {
                    newDirectoryId = agentCommunication.ExecutionResult.DirectoryId;

                    #region Actualizando el DirectoryId del agente

                    aservice.SetAgent(new AgentIntegrationService.AgentInformation()
                    {
                        AgentId = agentIdNew,
                        DirectoryId = newDirectoryId,
                        UserId = userid,
                        //Esto hay que hacerlo en el update porque sino da error
                        Gender = AgentIntegrationService.Gender.NA,
                        IdentityTypeId = AgentIntegrationService.IdentityType.NA
                        //Esto hay que hacerlo en el update porque sino da error
                    });

                    #endregion

                    #region Registrando el email

                    commTypeId = AgentIntegrationService.CommunicationTypes.Email;
                    directoryTypeId = AgentIntegrationService.DirectoryTypes.PersonalEmail;

                    aservice.SetAgentCommunication(new AgentIntegrationService.AgentInformation.ComunicationData()
                    {
                        DirDetailId = null,
                        DirectoryId = newDirectoryId,
                        CommTypeId = commTypeId,
                        Address = "email@email.com",
                        DirectoryTypeId = directoryTypeId,
                        IsPrimary = true,
                        UsrId = userid,
                        PhoneTypeId = AgentIntegrationService.PhoneTypes.NA
                    });

                    #endregion

                    #region Registrando los telefonos

                    commTypeId = AgentIntegrationService.CommunicationTypes.Phone;
                    directoryTypeId = AgentIntegrationService.DirectoryTypes.CellPhone;
                    var phoneTypeId = AgentIntegrationService.PhoneTypes.CellPhone;

                    aservice.SetAgentCommunication(new AgentIntegrationService.AgentInformation.ComunicationData()
                    {
                        DirDetailId = null,
                        DirectoryId = newDirectoryId,
                        CommTypeId = commTypeId,
                        DirectoryTypeId = directoryTypeId,
                        PhoneTypeId = phoneTypeId,
                        PhoneNumber = "809-111-1111",
                        IsPrimary = true,
                        UsrId = userid
                    });

                    commTypeId = AgentIntegrationService.CommunicationTypes.Phone;
                    directoryTypeId = AgentIntegrationService.DirectoryTypes.HomePhone;
                    phoneTypeId = AgentIntegrationService.PhoneTypes.Home;

                    aservice.SetAgentCommunication(new AgentIntegrationService.AgentInformation.ComunicationData()
                    {
                        DirDetailId = null,
                        DirectoryId = newDirectoryId,
                        CommTypeId = commTypeId,
                        DirectoryTypeId = directoryTypeId,
                        PhoneTypeId = phoneTypeId,
                        PhoneNumber = "809-222-2222",
                        IsPrimary = false,
                        UsrId = userid
                    });

                    commTypeId = AgentIntegrationService.CommunicationTypes.Phone;
                    directoryTypeId = AgentIntegrationService.DirectoryTypes.WorkPhone;
                    phoneTypeId = AgentIntegrationService.PhoneTypes.Work;

                    aservice.SetAgentCommunication(new AgentIntegrationService.AgentInformation.ComunicationData()
                    {
                        DirDetailId = null,
                        DirectoryId = newDirectoryId,
                        CommTypeId = commTypeId,
                        DirectoryTypeId = directoryTypeId,
                        PhoneTypeId = phoneTypeId,
                        PhoneNumber = "809-333-3333",
                        IsPrimary = false,
                        UsrId = userid
                    });


                    #endregion
                }

                #endregion

                #region Creacion de Codigo Unico

                aservice.SetAgentUniqueMatch(agentIdNew, null, identificationNumber, dob, userid);

                #endregion

                #region Asignacion de canal de distribucion y/o ventas al intermediario

                int distributionId = 5;//INTERMEDIARIOS 1

                aservice.SetAgentSalesChannel(new AgentIntegrationService.AgentInformation.SalesChannel()
                {
                    AgentId = agentIdNew,
                    DistributionId = distributionId,
                    UserId = userid
                });

                #endregion

                #region Asignacion de supervisor y/o cadena

                var chainId = AgentIntegrationService.ChainCodes.Auto;
                var bussinessLine = AgentIntegrationService.BussinessLines.Auto;

                aservice.SetAgentChainDetail(new AgentIntegrationService.AgentInformation.ChainDetail()
                {
                    AgentId = agentIdNew,
                    DistributionId = distributionId,
                    ChainDetId = null,
                    SupervisorAgentId = 31747,//Supervisor Atlantica - Oficina Plaza Uris
                    ChainId = chainId,
                    BussinessLine = bussinessLine,
                    AgentChainStatus = true,
                    DateAssigned = DateTime.Now,
                    DateUnassigned = null,
                    UserId = userid
                });

                #endregion

                #region Asignacion de Agent Business Line 

                aservice.SetAgentBusinessLine(new AgentIntegrationService.AgentInformation.BusinessLine()
                {
                    AgentId = agentIdNew,
                    OfficeId = officeId,
                    UsrId = 414
                });

                #endregion

                #region Asignacion de Oficina 

                aservice.SetAssignedAgentOffice(new AgentIntegrationService.AgentInformation.OfficeData()
                {
                    AgentId = agentIdNew,
                    OfficeId = officeId,
                    AssignedDate = DateTime.Now,
                    UnassignDate = null,
                    UsrId = 414
                });

                #endregion

                #region Registrando Documentos requeridos

                var allDocs = aservice.GetDocumentForAgents();

                if (allDocs.ExecutionResultList.Any())
                {
                    var docsTest = allDocs.ExecutionResultList.Take(2).ToList();

                    foreach (var d in docsTest)
                    {
                        var q = Guid.NewGuid().ToString("n").Substring(0, 8);
                        string filename = "TestDoct_" + q + ".pdf";
                        byte[] DocumentBinary = System.IO.File.ReadAllBytes(System.IO.Directory.GetCurrentDirectory() + "\\Test Document.pdf");

                        var docInserted = aservice.SetDocument(new AgentIntegrationService.Document()
                        {
                            DocTypeId = d.DocTypeId,
                            DocCategoryId = d.DocCategoryId,
                            DocumentBinary = DocumentBinary,
                            DocumentName = filename,
                            DocumentId = 0,
                            userId = userid
                        });

                        if (docInserted.ExecutionResult != null)
                        {
                            aservice.SetAgentDocument(new AgentIntegrationService.AgentInformation.AgentDocument()
                            {
                                AgentId = agentIdNew.GetValueOrDefault(),
                                DocumentId = docInserted.ExecutionResult.DocumentId.GetValueOrDefault(),
                                DocTypeId = d.DocTypeId.GetValueOrDefault(),
                                DocCategoryId = d.DocCategoryId.GetValueOrDefault(),
                                UserId = userid
                            });
                        }
                    }
                }


                #endregion

                #region Metodos opcionales, si se posee la informacion

                aservice.SetAgentIndex(agentIdNew, 2, userid);
                aservice.SetPropertyAgentIndex(agentIdNew, 2, userid);

                var docCategoryId = AgentIntegrationService.SuperintendenceLicencesID.Corridors;

                aservice.SetAgentLicense(new AgentIntegrationService.AgentInformation.LicenseData()
                {
                    AgentId = agentIdNew,
                    CountryId = 129,//RD
                    Id = "ABC-123789",
                    ValidDate = DateTime.Now,
                    ExpireDate = DateTime.Now.AddYears(1),
                    RevalidationDate = null,
                    DocCategoryId = docCategoryId,
                    UserId = userid
                });

                #endregion


                //obteniendo Linea de negocio
                var bussinessLineR = aservice.GetAgentBussinessLine(agentIdNew.GetValueOrDefault());
                string textBL = "";

                if (bussinessLineR.ExecutionResult != null)
                {
                    textBL = bussinessLineR.ExecutionResult.BussinessLineName;
                }

                #region Envio a los diferentes Cores

                if (textBL == "Auto")
                {

                    #region Vehiculo

                    /*
                     NOTA:

                     Cuando el intermediario sea de la linea de AUTO se debe agregarle al agente la UBICACION de sysflex
                     Para esto se debe seleccionar, los siguientes datos, tal cual existen en sysflex:                     
                     1 - Provincia
                     2 - Municipio
                     3 - Ciudad

                     */
                    /*
                   int UbicationSysflex = -1;

                   int provinceId = aservice.GetSysflexProvince(null).ExecutionResultList.FirstOrDefault().ProvinceId;
                   int municipalitieId = aservice.GetSysflexMunicipalities(provinceId, null).ExecutionResultList.FirstOrDefault().MunicipeId;
                   UbicationSysflex = aservice.GetSysflexCity(provinceId, municipalitieId, null).ExecutionResultList.FirstOrDefault().CitySysflexId;

                   #region Actualizando la ubicacion y dias de cancelacion del agente

                   aservice.SetAgent(new AgentIntegrationService.AgentInformation()
                   {
                       AgentId = agentIdNew,
                       UbicationSysflex = UbicationSysflex,
                       AutomaticCancellationDays = 30,
                       UserId = userid,

                       //Esto hay que hacerlo en el update porque sino da error
                       Gender = AgentIntegrationService.Gender.NA,
                       IdentityTypeId = AgentIntegrationService.IdentityType.NA
                       //Esto hay que hacerlo en el update porque sino da error
                   });

                   #endregion

                   #endregion

                   #region Envio al Core de Sysflex

                   string username = "jdotel";
                   aservice.SendAgentToCoreAuto(agentIdNew.GetValueOrDefault(), username);

                   #endregion
               }

               if (textBL == "Life")
               {
                   #region Vida

                   aservice.SendAgentToCoreLife(agentIdNew.GetValueOrDefault());

                   #endregion
               }

               if (textBL == "Health")
               {
                   #region Salud

                   string username = "jdotel";
                   aservice.SendAgentToCoreHealth(agentIdNew.GetValueOrDefault(), username);

                   #endregion
               }

              
           }
           */
                    #endregion
                    #endregion
                }
            }
        }
    }
}
