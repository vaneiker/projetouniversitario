﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Web;
using Newtonsoft.Json;

namespace SellersManagement.CustomCode
{
    public static class Utility
    {
        public class ActionModel
        {
            public CommonEnums.ActionTypes ActionType { get; set; }
            public string ActionJson { get; set; }
        }
        public class KeyValue
        {
            public string Key { get; set; }
            public string Value { get; set; }
        }

        public class Dimensions: KeyValue
        {
            public bool IsPastTime { get; set; }
        }
        public static int generateRandomSellerCode()
        {
            int randomSellerCode = 0;

            Random r = new Random();
            randomSellerCode = r.Next(0, 1000000);
           // string s = x.ToString("000000");

            return randomSellerCode;
        }

        /// <summary>
        /// Author: Lic. Carlos Ml. Lebron
        /// Created Date : 11-28-2014
        /// Deserializa un json a objeto T
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="Json"></param>
        /// <returns></returns>
        public static T deserializeJSON<T>(string Json) where T : class
        {
            dynamic result = null;

            try
            {
                result = JsonConvert.DeserializeObject<T>(Json);
            }
            catch (Exception ex)
            {
                var ErrorMessage = ex.Message;
            }

            return result;
        }

        public static string GetFullNameAndCode(string name, string code)
        {
            var result = "";
            if (!string.IsNullOrEmpty(name))
                result = string.Concat(name, "(", code, ")").ConvertValueToUpper();

            return result;
        }

        public static bool ByteArrayToFile(string _FileName, byte[] _ByteArray)
        {
            try
            {
                // Open file for reading
                System.IO.FileStream _FileStream = new System.IO.FileStream(_FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);

                // Writes a block of bytes to this stream using data from a byte array.
                _FileStream.Write(_ByteArray, 0, _ByteArray.Length);

                // close file stream
                _FileStream.Flush();
                _FileStream.Close();
                _FileStream.Dispose();
                return true;
            }
            catch (Exception _Exception)
            {
                // Error
                Console.WriteLine("Exception caught in process: {0}", _Exception.ToString());
            }

            // error occured, return false
            return false;
        }

        public static void SendMessage(String to, String Copia, String BCC, String Body, String From, String Subject,  bool ishtml = false)
        {
            try
            {
                var client = new SmtpClient { Host = System.Configuration.ConfigurationManager.AppSettings["STFEmailHost"] };
                client.Port = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["STFEmailPort"]);

                
                    var mensaje = new MailMessage();
                    if (!String.IsNullOrEmpty(to))
                    {
                        if (to.Split(',').Count() > 1)
                            mensaje.To.Add(to);
                        else
                            mensaje.To.Add(new MailAddress(to));
                    }

                    if (!String.IsNullOrEmpty(BCC))
                    {
                        if (BCC.Split(',').Count() > 1)
                            mensaje.Bcc.Add(BCC);
                        else
                            mensaje.Bcc.Add(new MailAddress(BCC));
                    }

                    if (!String.IsNullOrEmpty(Copia))
                    {
                        if (Copia.Split(',').Count() > 1)
                            mensaje.CC.Add(Copia);
                        else
                            mensaje.CC.Add(new MailAddress(Copia));
                    }

                    mensaje.IsBodyHtml = ishtml;
                    mensaje.Priority = MailPriority.High;
                    mensaje.Body = Body;
                    mensaje.Subject = Subject;
                    mensaje.From = new MailAddress(From);
                    //client.Send(mensaje);
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}