﻿
function loading() {
    $("#loading").css({
        'display': 'block'
    });
    return false;
}

function hide_loading() {
    $("#loading").css({
        'display': 'none'
    });
    return false;
}

function setDropdown()
{
    $('[data-toggle="tooltip"]').tooltip();
    $('[data-toggle="popover"]').popover();

    //Para implementar los dropdown multiselect
    $('select[multiple]').multiselect({
        columns: 1,
        placeholder: 'Seleccione',
        search: true,
        searchOptions: {
            'default': 'Buscar'
        },
        selectAll: true,
        texts: {
            selectAll: 'Seleccionar todos',
            unselectAll: 'Quitar seleccion'
        }
    });
}

function getDashboad(obj) {
    $("li.dos_lineas").removeClass("active");
    var url = '';
    var tab = $(obj).parent();
    $(tab).addClass("active");
    var url = $(obj).data('url');

    $.ajax({
        async: true,
        type: "GET",
        dataType: "html",
        contentType: "application/x-www-form-urlencoded",
        url: url,
        beforeSend: function () {
            loading();
        },
        success: function (datos) {
            $(".dashboard_content").html(datos);
            hide_loading();
            setDropdown();
        },
        timeout: 8000,
        error: function () {}
    });
    return false;
}

function getDashboad2(obj) {
    $("ul.steps li.dos_lineas").removeClass("active");
    var url = '';
    var tab = $(obj).parent();
    $(tab).addClass("active");
    var url = $(obj).data('url');

    $.ajax({
        async: true,
        type: "GET",
        dataType: "html",
        contentType: "application/x-www-form-urlencoded",
        url: url,
        beforeSend: function () {
            loading();
        },
        success: function (datos) {
            $(".dashboard_content_02").html(datos);
            hide_loading();
            setDropdown();
        },
        timeout: 8000,
        error: function () { }
    });
    return false;
}

function getDashboad3(obj) {
    $("li.dos_lineas").removeClass("active");
    var url = '';
    var tab = $(obj).parent();
    $(tab).addClass("active");
    var url = $(obj).data('url');

    $.ajax({
        async: true,
        type: "GET",
        dataType: "html",
        contentType: "application/x-www-form-urlencoded",
        url: url,
        beforeSend: function () {
            loading();
        },
        success: function (datos) {
            $(".dashboard_content_03").html(datos);
            hide_loading();
            setDropdown();
        },
        timeout: 8000,
        error: function () { }
    });
    return false;
}

function showProperties() {
    $(".properties_doc").toggle("slow");
}

function getPage(obj) {
    debugger
    var url = '';
    var url = $(obj).data('url');
    var redirect = $(obj).data('redirect');

    if (redirect == undefined) {
        $.ajax({
            async: true,
            type: "GET",
            dataType: "html",
            contentType: "application/x-www-form-urlencoded",
            url: url,
            beforeSend: function () {
                loading();
            },
            success: function (datos) {
                $(".st-app-tree-main-content").html(datos);
                hide_loading();
                setDropdown();
            },
            timeout: 8000,
            error: function () { }
        });
        return false;
    } else {
        window.location = url;
    }
}

function toogleTree() {
    if (window.innerWidth > 767) {
        //Tablets, iPads y Desktop
        if ($(".st-app-tree-menu").css("display") == "block") {
            $(".st-app-tree-main").addClass("st-app-tree-main-full-width");
            $(".st-app-tree-menu").addClass("st-app-tree-menu-full-width");
            $(".btn-st-menu-tree").html("<i class=\"fas fa-chevron-circle-right\"></i>");
        } else {
            $(".st-app-tree-main").removeClass("st-app-tree-main-full-width");
            $(".st-app-tree-menu").removeClass("st-app-tree-menu-full-width");
            $(".btn-st-menu-tree").html("<i class=\"fas fa-chevron-circle-left\"></i>");
        }
    } else {
        //Tablets vertical y moviles.
        if ($(".st-app-tree-menu").css("display") == "block") {
            $(".st-app-tree-menu").css("display", "none");
            $(".st-app-tree-main").addClass("st-app-tree-main-full-width");
            $(".st-app-tree-menu").addClass("st-app-tree-menu-full-width");
            $(".btn-st-menu-tree").html("<i class=\"fas fa-chevron-circle-right\"></i>");
        } else {
            $(".st-app-tree-menu").css("display", "block");
            $(".st-app-tree-main").removeClass("st-app-tree-main-full-width");
            $(".st-app-tree-menu").removeClass("st-app-tree-menu-full-width");
            $(".btn-st-menu-tree").html("<i class=\"fas fa-chevron-circle-left\"></i>");
        }
    }
}

function showChat() {
    $(".chat.chat-st").addClass("open");
    $(".show-chat-st").css("display", "none");
    $(".hide-chat-st").css("display", "block");
}

function hideChat() {
    $(".chat.chat-st").removeClass("open");
    $(".show-chat-st").css("display", "block");
    $(".hide-chat-st").css("display", "none");
}

function createWayToPay(value) {
    debugger
    switch (value) {
        case "1":
            $(".payment-method-credit-card").show("slow");
            $(".payment-method-transfer").hide("slow");
            $(".payment-ach").hide("slow");
            $(".payment-check").hide("slow");
            $(".payment-stb").hide("slow");
            $(".payment-check-promise").hide("slow");
            break;
        case "2":
            $(".payment-method-credit-card").hide("slow");
            $(".payment-method-transfer").hide("slow");
            $(".payment-ach").hide("slow");
            $(".payment-check").hide("slow");
            $(".payment-stb").show("slow");
            $(".payment-check-promise").hide("slow");
            break;
        case "3":
            $(".payment-method-credit-card").hide("slow");
            $(".payment-method-transfer").hide("slow");
            $(".payment-ach").show("slow");
            $(".payment-check").hide("slow");
            $(".payment-stb").hide("slow");
            $(".payment-check-promise").hide("slow");
            break;
        case "4":
            $(".payment-method-credit-card").hide("slow");
            $(".payment-method-transfer").hide("slow");
            $(".payment-ach").hide("slow");
            $(".payment-check").show("slow");
            $(".payment-stb").hide("slow");
            $(".payment-check-promise").hide("slow");
            break;
        case "5":
            $(".payment-method-credit-card").hide("slow");
            $(".payment-method-transfer").show("slow");
            $(".payment-ach").hide("slow");
            $(".payment-check").hide("slow");
            $(".payment-stb").hide("slow");
            $(".payment-check-promise").hide("slow");
            break;
        case "6":
            $(".payment-method-credit-card").hide("slow");
            $(".payment-method-transfer").hide("slow");
            $(".payment-ach").hide("slow");
            $(".payment-check").hide("slow");
            $(".payment-stb").hide("slow");
            $(".payment-check-promise").show("slow");
            break;
        default:
            $(".payment-method-credit-card").hide("slow");
            $(".payment-method-transfer").hide("slow");
            $(".payment-ach").hide("slow");
            $(".payment-check").hide("slow");
            $(".payment-stb").hide("slow");
            $(".payment-check-promise").hide("slow");
            break;
    }
}

function createWayToPay2(value) {
    debugger
    switch (value) {
        case "1":
            $(".metodo-almacenado .payment-method-credit-card").show("slow");
            $(".metodo-almacenado .payment-method-transfer").hide("slow");
            $(".metodo-almacenado .payment-ach").hide("slow");
            $(".metodo-almacenado .payment-check").hide("slow");
            $(".metodo-almacenado .payment-stb").hide("slow");
            $(".metodo-almacenado .payment-check-promise").hide("slow");
            break;
        case "2":
            $(".metodo-almacenado .payment-method-credit-card").hide("slow");
            $(".metodo-almacenado .payment-method-transfer").hide("slow");
            $(".metodo-almacenado .payment-ach").hide("slow");
            $(".metodo-almacenado .payment-check").hide("slow");
            $(".metodo-almacenado .payment-stb").show("slow");
            $(".metodo-almacenado .payment-check-promise").hide("slow");
            break;
        case "3":
            $(".metodo-almacenado .payment-method-credit-card").hide("slow");
            $(".metodo-almacenado .payment-method-transfer").hide("slow");
            $(".metodo-almacenado .payment-ach").show("slow");
            $(".metodo-almacenado .payment-check").hide("slow");
            $(".metodo-almacenado .payment-stb").hide("slow");
            $(".metodo-almacenado .payment-check-promise").hide("slow");
            break;
        case "4":
            $(".metodo-almacenado .payment-method-credit-card").hide("slow");
            $(".metodo-almacenado .payment-method-transfer").hide("slow");
            $(".metodo-almacenado .payment-ach").hide("slow");
            $(".metodo-almacenado .payment-check").show("slow");
            $(".metodo-almacenado .payment-stb").hide("slow");
            $(".metodo-almacenado .payment-check-promise").hide("slow");
            break;
        case "5":
            $(".metodo-almacenado .payment-method-credit-card").hide("slow");
            $(".metodo-almacenado .payment-method-transfer").show("slow");
            $(".metodo-almacenado .payment-ach").hide("slow");
            $(".metodo-almacenado .payment-check").hide("slow");
            $(".metodo-almacenado .payment-stb").hide("slow");
            $(".metodo-almacenado .payment-check-promise").hide("slow");
            break;
        case "6":
            $(".metodo-almacenado .payment-method-credit-card").hide("slow");
            $(".metodo-almacenado .payment-method-transfer").hide("slow");
            $(".metodo-almacenado .payment-ach").hide("slow");
            $(".metodo-almacenado .payment-check").hide("slow");
            $(".metodo-almacenado .payment-stb").hide("slow");
            $(".metodo-almacenado .payment-check-promise").show("slow");
            break;
        default:
            $(".metodo-almacenado .payment-method-credit-card").hide("slow");
            $(".metodo-almacenado .payment-method-transfer").hide("slow");
            $(".metodo-almacenado .payment-ach").hide("slow");
            $(".metodo-almacenado .payment-check").hide("slow");
            $(".metodo-almacenado .payment-stb").hide("slow");
            $(".metodo-almacenado .payment-check-promise").hide("slow");
            break;
    }
}

function whoMakePayment(value) {
    debugger
    switch (value) {
        case "1":
            $(".card-method-payment-customer").show("slow");
            $(".card-method-payment-agent").hide("slow");
            break;
        case "2":
            $(".card-method-payment-customer").hide("slow");
            $(".card-method-payment-agent").show("slow");
            break;
        default:
            $(".card-method-payment-customer").hide("slow");
            $(".card-method-payment-agent").hide("slow");
            break;
    }
}

function showDetailrow(id) {
    $(".row-item-" + id).toggle("slow");
}

function showForm() {
    $(".form").toggle("slow");
}

function getStatusWorkFlow(obj) {
    $('.workflow-st-node').removeClass('active');
    $(obj).addClass('active');
}

function agentprofile(value) {
    switch (value) {
        case "1":
            $(".profile-individual").show("slow");
            $(".profile-company").hide("slow");
            break;
        case "2":
            $(".profile-individual").hide("slow");
            $(".profile-company").show("slow");
            break;
        default:
            $(".profile-individual").hide("slow");
            $(".profile-company").hide("slow");
            break;
    }
}

function calcularMontoADebitar(value) {
    debugger
    var montoDomiciliar = $('#MontoDomiciliar').val();
    if (montoDomiciliar == '') {
        window.alert('Por favor indique el monto a domiciliar con esta forma de pago');
        $('#MontoDomiciliar').focus();
    }
    var MontoADebitar = 0.00;
    if (value != '0') {
        MontoADebitar = parseFloat(montoDomiciliar) / parseFloat(value);
    }
    $('.MontoADebitar').val(MontoADebitar);
}

$("document").ready(function () {
    $('[data-toggle="popover"]').popover();
    $('[data-toggle="tooltip"]').tooltip();

    //Para implementar los dropdown multiselect
    setDropdown();

    //Para cambiar el icono que muestra el menu izquierdo
    if (window.innerWidth > 767) {
    } else {
        $(".btn-st-menu-tree").html("<i class=\"fas fa-chevron-circle-right\"></i>");
        $(".st-app-tree-main").addClass("st-app-tree-main-full-width");
        $(".st-app-tree-menu").addClass("st-app-tree-menu-full-width");
    }
});