﻿var opacity_workflow = 1;
var down = true;
function loop() {
    var diagram = myDiagram;
    setTimeout(function () {
        var oldskips = diagram.skipsUndoManager;
        diagram.skipsUndoManager = true;
        diagram.links.each(function (link) {
            var shape = link.findObject("PIPE");
            var off = shape.strokeDashOffset - 3;
            // animate (move) the stroke dash
            shape.strokeDashOffset = (off <= 0) ? 60 : off;
            // animte (strobe) the opacity_workflow:
            if (down) opacity_workflow = opacity_workflow - 0.01;
            else opacity_workflow = opacity_workflow + 0.003;
            if (opacity_workflow <= 0) { down = !down; opacity_workflow = 0; }
            if (opacity_workflow > 1) { down = !down; opacity_workflow = 1; }
            shape.opacity = opacity_workflow;
        });
        diagram.skipsUndoManager = oldskips;
        loop();
    }, 60);
}

function onSelectionChanged() {
    var node = myDiagram.selection.first();
    if (!(node instanceof go.Node)) return;
    var data = node.data;
    /*
    var image = document.getElementById("Image");
    var title = document.getElementById("Title");
    var description = document.getElementById("Description");

    if (data.source) {
        image.src = data.source;
        //image.alt = data.caption;
    } else {
        image.src = "";
        image.alt = "";
    }
    title.textContent = data.name;
    description.textContent = data.description;
    */
    debugger
    $('.table-cases').css('display', 'block');
}

//Workflow con Steps del detalle de un caso
function init_workflow(myModel) {
    var roundedRectangleParams = {
        parameter1: 2,  // set the rounded corner
        spot1: go.Spot.TopLeft,
        spot2: go.Spot.BottomRight  // make content go all the way to inside edges of rounded corners
    };

    if (window.goSamples) goSamples();  // init for these samples -- you don't need to call this

    // Abstract colors
    var Colors = {
        "red": "#be4b15",
        "green": "#52ce60",
        "blue": "#6ea5f8",
        "lightred": "#fd8852",
        "lightblue": "#afd4fe",
        "lightgreen": "#b9e986",
        "pink": "#faadc1",
        "purple": "#d689ff",
        "orange": "#f3a334",
        "gray": "#f2f2f2"
    }

    var ColorNames = [];
    for (var n in Colors) ColorNames.push(n);

    // a conversion function for translating general color names to specific colors
    function colorFunc(colorname) {
        var c = Colors[colorname]
        if (c) {
            return c;
        }
        return "gray";
    }

    var goJSlib = go.GraphObject.make;  // for conciseness in defining templates
    myDiagram = goJSlib(go.Diagram, "myDiagramDiv",  // create a Diagram for the DIV HTML element
        {
            initialAutoScale: go.Diagram.Uniform,  // scale to show all of the contents
            //"ChangedSelection": onSelectionChanged, // view additional information
            maxSelectionCount: 1,  // don't allow users to select more than one thing at a time
            isReadOnly: true
            //layout: goJSlib(go.TreeLayout, // specify a Diagram.layout that arranges trees
            //{
            //angle: 90,
            //layerSpacing: 35
            //})
        }
    );

    myDiagram.nodeTemplate =
        goJSlib(go.Node, "Spot",
            {
                locationObjectName: "PORT",
                locationSpot: go.Spot.Top,  // location point is the middle top of the PORT
                cursor: "pointer",
                isShadowed: true,
                shadowBlur: 2,
                shadowOffset: new go.Point(0, 2),
                shadowColor: "rgba(0, 0, 0, .30)",
                width: 180,
                toolTip:
                    goJSlib("ToolTip",
                        goJSlib(go.TextBlock, { margin: 4, width: 180 },
                            new go.Binding("text", "", function (data) { return data.name + ":\n\n" + data.comment; }))
                    ),
                selectionAdornmentTemplate:  // selection adornment to match shape of nodes
                    goJSlib(
                        go.Adornment, "Auto",
                        goJSlib(
                            go.Shape,
                            "RoundedRectangle",
                            roundedRectangleParams,
                            {
                                fill: null,
                                stroke: "#76c9ed",
                                strokeWidth: 3
                            }
                        ),
                        goJSlib(go.Placeholder)
                    )  // end Adornment
            },
            new go.Binding("background", "color", colorFunc),
            new go.Binding("location", "pos", go.Point.parse).makeTwoWay(go.Point.stringify),
            // The main element of the Spot panel is a vertical panel housing an optional icon,
            // plus a rectangle that acts as the port
            goJSlib(go.Panel, "Vertical",
                goJSlib(go.Panel, "Horizontal",
                    { margin: 4 },
                    goJSlib(go.Picture,  // flag image, only visible if a nation is specified
                        {
                            margin: 4,
                            width: 55,
                            height: 66
                            //background: "red"
                        },
                        new go.Binding("source")
                    ),
                    goJSlib(go.Panel, "Table",
                        goJSlib(go.TextBlock,
                            {
                                row: 0,
                                alignment: go.Spot.Left,
                                font: "16px Roboto, sans-serif",
                                stroke: "rgba(0, 0, 0, .87)",
                                maxSize: new go.Size(160, NaN),
                                margin: 2
                            },
                            new go.Binding("text", "name")
                        ),
                        goJSlib(go.TextBlock,
                            {
                                row: 1, alignment: go.Spot.Left,
                                maxSize: new go.Size(160, NaN),
                                margin: 2
                            },
                            new go.Binding("text", "description")
                        ),
                    )
                ),
            ),
        );

    function updatePortHeight(node, link, port) {
        var sideinputs = 0;
        var sideoutputs = 0;
        node.findLinksConnected().each(function (l) {
            if (l.toNode === node && l.toSpot === go.Spot.LeftSide) sideinputs++;
            if (l.fromNode === node && l.fromSpot === go.Spot.RightSide) sideoutputs++;
        });
        var tot = Math.max(sideinputs, sideoutputs);
        tot = Math.max(1, Math.min(tot, 2));
        port.height = tot * (10 + 2) + 2;  // where 10 is the link path's strokeWidth
    }

    myDiagram.linkTemplate =
        goJSlib(go.Link,
            {
                layerName: "Background",
                routing: go.Link.Orthogonal,
                corner: 15,
                reshapable: true,
                resegmentable: true,
                fromSpot: go.Spot.BottomSide,
                toSpot: go.Spot.TopSide
            },
            // make sure links come in from the proper direction and go out appropriately
            new go.Binding("fromSpot", "fromSpot", go.Spot.parse),
            new go.Binding("toSpot", "toSpot", go.Spot.parse),
            //new go.Binding("points").makeTwoWay(),
            // mark each Shape to get the link geometry with isPanelMain: true
            goJSlib(go.Shape, { isPanelMain: true, stroke: "gray", strokeWidth: 10 },
                // get the default stroke color from the fromNode
                new go.Binding("stroke", "fromNode", function (n) { return go.Brush.lighten((n && Colors[n.data.colorlink]) || "#9f9f9f"); }).ofObject(),
                // but use the link's data.color if it is set
                new go.Binding("stroke", "colorlink", colorFunc)),
            //goJSlib(go.Shape, { toArrow: "Standard", stroke: "#f00", strokeWidth: 6 },
            //new go.Binding("fill", "fromNode", function (n) { return go.Brush.lighten((n && Colors[n.data.colorlink]) || "#9f9f9f"); }).ofObject(),
            //new go.Binding("stroke", "fromNode", function (n) { return go.Brush.lighten((n && Colors[n.data.colorlink]) || "#9f9f9f"); }).ofObject()),
            goJSlib(go.Shape, { isPanelMain: true, stroke: "white", strokeWidth: 3, name: "PIPE", strokeDashArray: [20, 40] })
        );

    var SpotNames = ["Top", "Left", "Right", "Bottom", "TopSide", "LeftSide", "RightSide", "BottomSide"];



    //myDiagram.model = go.Model.fromJson(document.getElementById("mySavedModel").textContent);
    myDiagram.model = go.Model.fromJson(myModel);

    loop();  // animate some flow through the pipes
}

//Workflow con Steps numerados paso a paso
function init_workflow2(myModel, divRender) {
    var roundedRectangleParams = {
        parameter1: 2,  // set the rounded corner
        spot1: go.Spot.TopLeft,
        spot2: go.Spot.BottomRight  // make content go all the way to inside edges of rounded corners
    };

    if (window.goSamples) goSamples();  // init for these samples -- you don't need to call this

    // Abstract colors
    var Colors = {
        "red": "#be4b15",
        "green": "#52ce60",
        "blue": "#6ea5f8",
        "lightred": "#fd8852",
        "lightblue": "#afd4fe",
        "lightgreen": "#b9e986",
        "pink": "#faadc1",
        "purple": "#d689ff",
        "orange": "#f3a334",
        "gray": "#f2f2f2"
    }

    var ColorNames = [];
    for (var n in Colors) ColorNames.push(n);

    // a conversion function for translating general color names to specific colors
    function colorFunc(colorname) {
        var c = Colors[colorname]
        if (c) {
            return c;
        }
        return "gray";
    }

    var goJSlib = go.GraphObject.make;  // for conciseness in defining templates
    myDiagram = goJSlib(go.Diagram, divRender,  // create a Diagram for the DIV HTML element
        {
            initialAutoScale: go.Diagram.Uniform,  // scale to show all of the contents
            "ChangedSelection": onSelectionChanged, // view additional information
            maxSelectionCount: 1,  // don't allow users to select more than one thing at a time
            isReadOnly: true
            //layout: goJSlib(go.TreeLayout, // specify a Diagram.layout that arranges trees
            //{
            //angle: 90,
            //layerSpacing: 35
            //})
        }
    );

    myDiagram.nodeTemplate =
        goJSlib(go.Node, "Spot",
            {
                locationObjectName: "PORT",
                locationSpot: go.Spot.Top,  // location point is the middle top of the PORT
                cursor: "pointer",
                isShadowed: true,
                shadowBlur: 2,
                shadowOffset: new go.Point(0, 2),
                shadowColor: "rgba(0, 0, 0, .30)",
                height: 90,
                width: 180,
                toolTip:
                    goJSlib("ToolTip",
                        goJSlib(go.TextBlock, { margin: 4, width: 180 },
                            new go.Binding("text", "", function (data) { return data.name + ":\n\n" + data.comment; }))
                    ),
                selectionAdornmentTemplate:  // selection adornment to match shape of nodes
                    goJSlib(
                        go.Adornment, "Auto",
                        goJSlib(
                            go.Shape,
                            "RoundedRectangle",
                            roundedRectangleParams,
                            {
                                fill: "rgba(118, 201, 237, 0.25)",
                                stroke: "#76c9ed",
                                strokeWidth: 3
                            }
                        ),
                        goJSlib(go.Placeholder)
                    )  // end Adornment
            },
            new go.Binding("background", "color", colorFunc),
            new go.Binding("location", "pos", go.Point.parse).makeTwoWay(go.Point.stringify),
            // The main element of the Spot panel is a vertical panel housing an optional icon,
            // plus a rectangle that acts as the port
            goJSlib(go.Panel, "Vertical",
                goJSlib(go.Panel, "Horizontal",
                    {
                        margin: 2
                    },
                    goJSlib(go.Panel, "Table",
                        goJSlib(go.TextBlock,
                            {
                                row: 0,
                                alignment: go.Spot.Center,
                                textAlign: "center",
                                font: "bold 35px Roboto, sans-serif",
                                stroke: "#004d68",
                                margin: 0,
                                width: 55,
                            },
                            new go.Binding("text", "step", function (step) { return step + ""; }),
                            new go.Binding("visible", "step", function (step) { return step != 0; })
                        ),
                        goJSlib(go.TextBlock,
                            {
                                row: 1,
                                alignment: go.Spot.Center,
                                text: "Paso",
                                textAlign: "center",
                                font: "bold 12px Roboto, sans-serif",
                                stroke: "#004d68",
                                margin: -1,
                            },
                            new go.Binding("visible", "step", function (step) { return step != 0; })
                        ),
                        goJSlib(go.Picture,  // flag image, only visible if a nation is specified
                            {
                                row: 0,
                                alignment: go.Spot.Center,
                                margin: 1,
                                width: 55,
                                height: 66
                                //background: "red"
                            },
                            new go.Binding("source"),
                            new go.Binding("visible", "step", function (step) { return step == 0; })
                        ),
                    ),
                    goJSlib(go.Panel, "Table",
                        goJSlib(go.TextBlock,
                            {
                                row: 0,
                                alignment: go.Spot.Left,
                                font: "16px Roboto, sans-serif",
                                stroke: "rgba(0, 0, 0, .87)",
                                maxSize: new go.Size(160, NaN),
                                margin: 3,
                                width: 112
                            },
                            new go.Binding("text", "name")
                        ),
                        goJSlib(
                            go.Shape,
                            "RoundedRectangle",
                            roundedRectangleParams,
                            {
                                stroke: '#b9e986',
                                fill: '#b9e986',
                                row: 1,
                                alignment: go.Spot.Left,
                                strokeWidth: 1,
                                height: 20,
                                width: 30,
                            },
                        ),
                        goJSlib(go.TextBlock,
                            {
                                row: 1, alignment: go.Spot.Left,
                                maxSize: new go.Size(160, NaN),
                                margin: 4
                            },
                            new go.Binding("text", "casesIntime")
                        ),
                        goJSlib(
                            go.Shape,
                            "RoundedRectangle",
                            roundedRectangleParams,
                            {
                                stroke: '#f3a334',
                                fill: '#ffc107',
                                row: 1,
                                alignment: go.Spot.Center,
                                strokeWidth: 1,
                                height: 20,
                                width: 30,
                            },
                        ),
                        goJSlib(go.TextBlock,
                            {
                                row: 1, alignment: go.Spot.Center,
                                maxSize: new go.Size(160, NaN),
                                margin: 2
                            },
                            new go.Binding("text", "casesWarning")
                        ),
                        goJSlib(
                            go.Shape,
                            "RoundedRectangle",
                            roundedRectangleParams,
                            {
                                stroke: '#dc3545',
                                fill: '#dc3545',
                                row: 1,
                                alignment: go.Spot.Right,
                                strokeWidth: 1,
                                margin: 4,
                                height: 20,
                                width: 30,
                            },
                        ),
                        goJSlib(go.TextBlock,
                            {
                                row: 1, alignment: go.Spot.Right,
                                maxSize: new go.Size(160, NaN),
                                margin: 4,
                                stroke: '#fff'
                            },
                            new go.Binding("text", "casesDanger")
                        ),
                        goJSlib(go.TextBlock,
                            {
                                row: 2, alignment: go.Spot.Left,
                                maxSize: new go.Size(160, NaN),
                                margin: 2
                            },
                            new go.Binding("text", "casesTotal")
                        ),
                    )
                ),
            ),
        );

    function updatePortHeight(node, link, port) {
        var sideinputs = 0;
        var sideoutputs = 0;
        node.findLinksConnected().each(function (l) {
            if (l.toNode === node && l.toSpot === go.Spot.LeftSide) sideinputs++;
            if (l.fromNode === node && l.fromSpot === go.Spot.RightSide) sideoutputs++;
        });
        var tot = Math.max(sideinputs, sideoutputs);
        tot = Math.max(1, Math.min(tot, 2));
        port.height = tot * (10 + 2) + 2;  // where 10 is the link path's strokeWidth
    }

    myDiagram.linkTemplate =
        goJSlib(go.Link,
            {
                layerName: "Background",
                routing: go.Link.Orthogonal,
                corner: 15,
                reshapable: true,
                resegmentable: true,
                fromSpot: go.Spot.BottomSide,
                toSpot: go.Spot.TopSide
            },
            // make sure links come in from the proper direction and go out appropriately
            new go.Binding("fromSpot", "fromSpot", go.Spot.parse),
            new go.Binding("toSpot", "toSpot", go.Spot.parse),
            //new go.Binding("points").makeTwoWay(),
            // mark each Shape to get the link geometry with isPanelMain: true
            goJSlib(go.Shape, { isPanelMain: true, stroke: "gray", strokeWidth: 10 },
                // get the default stroke color from the fromNode
                new go.Binding("stroke", "fromNode", function (n) { return go.Brush.lighten((n && Colors[n.data.colorlink]) || "#9f9f9f"); }).ofObject(),
                // but use the link's data.color if it is set
                new go.Binding("stroke", "colorlink", colorFunc)),
            //goJSlib(go.Shape, { toArrow: "Standard", stroke: "#f00", strokeWidth: 6 },
            //new go.Binding("fill", "fromNode", function (n) { return go.Brush.lighten((n && Colors[n.data.colorlink]) || "#9f9f9f"); }).ofObject(),
            //new go.Binding("stroke", "fromNode", function (n) { return go.Brush.lighten((n && Colors[n.data.colorlink]) || "#9f9f9f"); }).ofObject()),
            goJSlib(go.Shape, { isPanelMain: true, stroke: "white", strokeWidth: 3, name: "PIPE", strokeDashArray: [20, 40] })
        );

    var SpotNames = ["Top", "Left", "Right", "Bottom", "TopSide", "LeftSide", "RightSide", "BottomSide"];



    //myDiagram.model = go.Model.fromJson(document.getElementById("mySavedModel").textContent);
    myDiagram.model = go.Model.fromJson(myModel);

    loop();  // animate some flow through the pipes
}

//Workflow con Steps numerados paso a paso
function init_workflow3(myModel, divRender) {
    var roundedRectangleParams = {
        parameter1: 2,  // set the rounded corner
        spot1: go.Spot.TopLeft,
        spot2: go.Spot.BottomRight  // make content go all the way to inside edges of rounded corners
    };

    if (window.goSamples) goSamples();  // init for these samples -- you don't need to call this

    // Abstract colors
    var Colors = {
        "red": "#be4b15",
        "green": "#52ce60",
        "blue": "#6ea5f8",
        "lightred": "#fd8852",
        "lightblue": "#afd4fe",
        "lightgreen": "#b9e986",
        "pink": "#faadc1",
        "purple": "#d689ff",
        "orange": "#f3a334",
        "gray": "#f2f2f2"
    }

    var ColorNames = [];
    for (var n in Colors) ColorNames.push(n);

    // a conversion function for translating general color names to specific colors
    function colorFunc(colorname) {
        var c = Colors[colorname]
        if (c) {
            return c;
        }
        return "gray";
    }

    var goJSlib = go.GraphObject.make;  // for conciseness in defining templates
    myDiagram = goJSlib(go.Diagram, divRender,  // create a Diagram for the DIV HTML element
        {
            initialAutoScale: go.Diagram.Uniform,  // scale to show all of the contents
            "ChangedSelection": onSelectionChanged, // view additional information
            maxSelectionCount: 1,  // don't allow users to select more than one thing at a time
            isReadOnly: true
            //layout: goJSlib(go.TreeLayout, // specify a Diagram.layout that arranges trees
            //{
            //angle: 90,
            //layerSpacing: 35
            //})
        }
    );

    myDiagram.nodeTemplate =
        goJSlib(go.Node, "Spot",
            {
                locationObjectName: "PORT",
                locationSpot: go.Spot.Top,  // location point is the middle top of the PORT
                cursor: "pointer",
                isShadowed: true,
                shadowBlur: 2,
                shadowOffset: new go.Point(0, 2),
                shadowColor: "rgba(0, 0, 0, .30)",
                height: 90,
                width: 180,
                toolTip:
                    goJSlib("ToolTip",
                        goJSlib(go.TextBlock, { margin: 4, width: 180 },
                            new go.Binding("text", "", function (data) { return data.name + ":\n\n" + data.comment; }))
                    ),
                selectionAdornmentTemplate:  // selection adornment to match shape of nodes
                    goJSlib(
                        go.Adornment, "Auto",
                        goJSlib(
                            go.Shape,
                            "RoundedRectangle",
                            roundedRectangleParams,
                            {
                                fill: "rgba(118, 201, 237, 0.25)",
                                stroke: "#76c9ed",
                                strokeWidth: 3
                            }
                        ),
                        goJSlib(go.Placeholder)
                    )  // end Adornment
            },
            new go.Binding("background", "color", colorFunc),
            new go.Binding("location", "pos", go.Point.parse).makeTwoWay(go.Point.stringify),
            // The main element of the Spot panel is a vertical panel housing an optional icon,
            // plus a rectangle that acts as the port
            goJSlib(go.Panel, "Vertical",
                goJSlib(go.Panel, "Horizontal",
                    {
                        margin: 2
                    },
                    goJSlib(go.Panel, "Table",
                        goJSlib(go.TextBlock,
                            {
                                row: 0,
                                alignment: go.Spot.Center,
                                textAlign: "center",
                                font: "bold 35px Roboto, sans-serif",
                                stroke: "#004d68",
                                margin: 0,
                                width: 55,
                            },
                            new go.Binding("text", "step", function (step) { return step + ""; }),
                            new go.Binding("visible", "step", function (step) { return step != 0; })
                        ),
                        goJSlib(go.TextBlock,
                            {
                                row: 1,
                                alignment: go.Spot.Center,
                                text: "Paso",
                                textAlign: "center",
                                font: "bold 12px Roboto, sans-serif",
                                stroke: "#004d68",
                                margin: -1,
                            },
                            new go.Binding("visible", "step", function (step) { return step != 0; })
                        ),
                        goJSlib(go.Picture,  // flag image, only visible if a nation is specified
                            {
                                row: 0,
                                alignment: go.Spot.Center,
                                margin: 1,
                                width: 55,
                                height: 66
                                //background: "red"
                            },
                            new go.Binding("source"),
                            new go.Binding("visible", "step", function (step) { return step == 0; })
                        ),
                    ),
                    goJSlib(go.Panel, "Table",
                        goJSlib(go.TextBlock,
                            {
                                row: 0,
                                alignment: go.Spot.Left,
                                font: "16px Roboto, sans-serif",
                                stroke: "rgba(0, 0, 0, .87)",
                                maxSize: new go.Size(160, NaN),
                                margin: 3,
                                width: 112
                            },
                            new go.Binding("text", "name")
                        ),
                        goJSlib(
                            go.Shape,
                            "RoundedRectangle",
                            roundedRectangleParams,
                            {
                                stroke: '#b9e986',
                                fill: '#b9e986',
                                row: 1,
                                alignment: go.Spot.Left,
                                strokeWidth: 1,
                                height: 20,
                                width: 30,
                            },
                        ),
                        goJSlib(go.TextBlock,
                            {
                                row: 1, alignment: go.Spot.Left,
                                maxSize: new go.Size(160, NaN),
                                margin: 4
                            },
                            new go.Binding("text", "casesIntime")
                        ),
                        goJSlib(
                            go.Shape,
                            "RoundedRectangle",
                            roundedRectangleParams,
                            {
                                stroke: '#f3a334',
                                fill: '#ffc107',
                                row: 1,
                                alignment: go.Spot.Center,
                                strokeWidth: 1,
                                height: 20,
                                width: 30,
                            },
                        ),
                        goJSlib(go.TextBlock,
                            {
                                row: 1, alignment: go.Spot.Center,
                                maxSize: new go.Size(160, NaN),
                                margin: 2
                            },
                            new go.Binding("text", "casesWarning")
                        ),
                        goJSlib(
                            go.Shape,
                            "RoundedRectangle",
                            roundedRectangleParams,
                            {
                                stroke: '#dc3545',
                                fill: '#dc3545',
                                row: 1,
                                alignment: go.Spot.Right,
                                strokeWidth: 1,
                                margin: 4,
                                height: 20,
                                width: 30,
                            },
                        ),
                        goJSlib(go.TextBlock,
                            {
                                row: 1, alignment: go.Spot.Right,
                                maxSize: new go.Size(160, NaN),
                                margin: 4,
                                stroke: '#fff'
                            },
                            new go.Binding("text", "casesDanger")
                        ),
                        goJSlib(go.TextBlock,
                            {
                                row: 2, alignment: go.Spot.Left,
                                maxSize: new go.Size(160, NaN),
                                margin: 2
                            },
                            new go.Binding("text", "casesTotal")
                        ),
                    )
                ),
            ),
        );

    function updatePortHeight(node, link, port) {
        var sideinputs = 0;
        var sideoutputs = 0;
        node.findLinksConnected().each(function (l) {
            if (l.toNode === node && l.toSpot === go.Spot.LeftSide) sideinputs++;
            if (l.fromNode === node && l.fromSpot === go.Spot.RightSide) sideoutputs++;
        });
        var tot = Math.max(sideinputs, sideoutputs);
        tot = Math.max(1, Math.min(tot, 2));
        port.height = tot * (10 + 2) + 2;  // where 10 is the link path's strokeWidth
    }

    myDiagram.linkTemplate =
        goJSlib(go.Link,
            {
                layerName: "Background",
                routing: go.Link.Orthogonal,
                corner: 15,
                reshapable: true,
                resegmentable: true,
                fromSpot: go.Spot.BottomSide,
                toSpot: go.Spot.TopSide
            },
            // make sure links come in from the proper direction and go out appropriately
            new go.Binding("fromSpot", "fromSpot", go.Spot.parse),
            new go.Binding("toSpot", "toSpot", go.Spot.parse),
            //new go.Binding("points").makeTwoWay(),
            // mark each Shape to get the link geometry with isPanelMain: true
            goJSlib(go.Shape, { isPanelMain: true, stroke: "gray", strokeWidth: 10 },
                // get the default stroke color from the fromNode
                new go.Binding("stroke", "fromNode", function (n) { return go.Brush.lighten((n && Colors[n.data.colorlink]) || "#9f9f9f"); }).ofObject(),
                // but use the link's data.color if it is set
                new go.Binding("stroke", "colorlink", colorFunc)),
            //goJSlib(go.Shape, { toArrow: "Standard", stroke: "#f00", strokeWidth: 6 },
            //new go.Binding("fill", "fromNode", function (n) { return go.Brush.lighten((n && Colors[n.data.colorlink]) || "#9f9f9f"); }).ofObject(),
            //new go.Binding("stroke", "fromNode", function (n) { return go.Brush.lighten((n && Colors[n.data.colorlink]) || "#9f9f9f"); }).ofObject()),
            goJSlib(go.Shape, { isPanelMain: true, stroke: "white", strokeWidth: 3, name: "PIPE", strokeDashArray: [20, 40] })
        );

    var SpotNames = ["Top", "Left", "Right", "Bottom", "TopSide", "LeftSide", "RightSide", "BottomSide"];



    //myDiagram.model = go.Model.fromJson(document.getElementById("mySavedModel").textContent);
    myDiagram.model = go.Model.fromJson(myModel);

    loop();  // animate some flow through the pipes
}