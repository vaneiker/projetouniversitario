﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TemplateSTLWeb.Controllers
{
    public class DashboardController : Controller
    {
        // GET: Dashboard
        public ActionResult _PartialDashboard01()
        {
            return PartialView();
        }
        public ActionResult _PartialDashboard02()
        {
            return PartialView();
        }
        public ActionResult _PartialDashboard03()
        {
            return PartialView();
        }
        public ActionResult _PartialDashboard04()
        {
            return PartialView();
        }
    }
}